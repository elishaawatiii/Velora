-- Velora store schema. Prices are integer Kenyan shillings (no floats).
-- Authorization is enforced in server functions (this driver is privileged).

create table if not exists profiles (
  id text primary key,
  full_name text,
  email text,
  phone text,
  avatar_url text,
  role text not null default 'customer' check (role in ('customer', 'admin')),
  is_verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists categories (
  id text primary key,
  name text not null,
  slug text not null unique,
  description text,
  image_url text,
  is_active boolean not null default true,
  display_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists products (
  id text primary key,
  category_id text not null references categories(id),
  name text not null,
  slug text not null unique,
  description text not null default '',
  price integer not null check (price >= 0),
  compare_at_price integer check (compare_at_price is null or compare_at_price >= 0),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  low_stock_threshold integer not null default 5,
  sku text not null unique,
  main_image_url text not null,
  is_active boolean not null default true,
  is_featured boolean not null default false,
  search_text text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists products_category_idx on products (category_id);
create index if not exists products_active_idx on products (is_active, is_featured);
create index if not exists products_search_idx on products (search_text);

create table if not exists product_images (
  id text primary key,
  product_id text not null references products(id) on delete cascade,
  image_url text not null,
  display_order int not null default 0,
  alt_text text,
  created_at timestamptz not null default now()
);

create table if not exists product_variants (
  id text primary key,
  product_id text not null references products(id) on delete cascade,
  size text,
  color text,
  sku text not null unique,
  price integer,
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  created_at timestamptz not null default now()
);

create index if not exists product_variants_product_idx on product_variants (product_id);

create table if not exists carts (
  id text primary key,
  user_id text not null unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists cart_items (
  id text primary key,
  cart_id text not null references carts(id) on delete cascade,
  product_id text not null references products(id),
  variant_id text references product_variants(id),
  quantity integer not null check (quantity > 0),
  unique (cart_id, product_id, variant_id)
);

create table if not exists delivery_zones (
  id text primary key,
  name text not null,
  fee integer not null check (fee >= 0),
  eta_text text not null default '2–4 days',
  is_active boolean not null default true,
  display_order int not null default 0
);

create table if not exists addresses (
  id text primary key,
  user_id text not null,
  label text,
  recipient_name text not null,
  phone text not null,
  line1 text not null,
  city text not null,
  zone_id text references delivery_zones(id),
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists addresses_user_idx on addresses (user_id);

create table if not exists orders (
  id text primary key,
  user_id text not null,
  order_number text not null unique,
  subtotal integer not null,
  delivery_fee integer not null,
  total integer not null,
  currency text not null default 'KES',
  status text not null default 'pending'
    check (status in ('pending','confirmed','processing','shipped','delivered','cancelled')),
  payment_status text not null default 'pending'
    check (payment_status in ('pending','initiated','paid','failed','cancelled','refunded')),
  payment_method text not null default 'mpesa'
    check (payment_method in ('mpesa','cod')),
  customer_name text not null,
  customer_phone text not null,
  mpesa_phone text,
  delivery_address text not null,
  delivery_zone_id text references delivery_zones(id),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists orders_user_idx on orders (user_id, created_at desc);
create index if not exists orders_status_idx on orders (status, payment_status);

create table if not exists order_items (
  id text primary key,
  order_id text not null references orders(id) on delete cascade,
  product_id text,
  variant_id text,
  product_name_snapshot text not null,
  sku_snapshot text not null,
  size_snapshot text,
  quantity integer not null,
  unit_price integer not null,
  total_price integer not null
);

create table if not exists payments (
  id text primary key,
  order_id text not null references orders(id),
  user_id text not null,
  amount integer not null,
  currency text not null default 'KES',
  provider text not null default 'mpesa',
  checkout_request_id text unique,
  merchant_request_id text,
  receipt_number text,
  phone_number text,
  status text not null default 'initiated'
    check (status in ('initiated','paid','failed','cancelled','timeout')),
  result_code text,
  result_desc text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists payments_order_idx on payments (order_id);

create table if not exists favorites (
  user_id text not null,
  product_id text not null references products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

create table if not exists notifications (
  id text primary key,
  user_id text not null,
  title text not null,
  body text not null,
  is_read boolean not null default false,
  link text,
  created_at timestamptz not null default now()
);

create index if not exists notifications_user_idx on notifications (user_id, created_at desc);

create table if not exists store_settings (
  key text primary key,
  value text not null
);

create sequence if not exists order_seq start 1042;
