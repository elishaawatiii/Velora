-- Development catalogue for Velora. Safe to re-run (upserts).

insert into store_settings (key, value) values
  ('store_name', 'Velora'),
  ('store_tagline', 'Everyday fashion, delivered across Kenya'),
  ('whatsapp_phone', '254711000000'),
  ('support_email', 'hello@velora.shop'),
  ('follow_handle', 'Velora Store')
on conflict (key) do nothing;

insert into delivery_zones (id, name, fee, eta_text, display_order) values
  ('zone_cbd', 'Nairobi CBD', 200, 'Same day – next day', 1),
  ('zone_nairobi', 'Nairobi (other)', 350, '1–2 days', 2),
  ('zone_metro', 'Kiambu / Machakos / Kajiado', 500, '2–3 days', 3),
  ('zone_kenya', 'Rest of Kenya', 800, '3–5 days', 4)
on conflict (id) do nothing;

insert into categories (id, name, slug, description, image_url, display_order) values
  ('cat_men', 'Men''s outfit', 'mens-outfit', 'Jackets, shirts and everyday menswear.', '/products/bomber-jacket.jpg', 1),
  ('cat_women', 'Woman''s outfit', 'womens-outfit', 'Dresses and ready-to-wear for women.', '/products/black-dress.jpg', 2),
  ('cat_mfoot', 'Men''s footwear', 'mens-footwear', 'Casual and formal shoes for men.', '/products/black-oxfords.jpg', 3),
  ('cat_wfoot', 'Women''s footwear', 'womens-footwear', 'Boots and everyday shoes for women.', '/products/ankle-boots.jpg', 4)
on conflict (id) do update set name = excluded.name, image_url = excluded.image_url;

insert into products (
  id, category_id, name, slug, description, price, compare_at_price,
  stock_quantity, sku, main_image_url, is_active, is_featured, search_text
) values
(
  'prod_grey_shoe', 'cat_mfoot', 'Grey Casual shoe', 'grey-casual-shoe',
  'Soft canvas slip-ons with a clean white sole. Easy with jeans, chinos or a weekend set. Cushioned insole, unlined for Nairobi heat.',
  4500, 5200, 28, 'VEL-SHOE-001', '/products/grey-slipons.jpg', true, true,
  'grey casual shoe slip on canvas mens footwear vel-shoe-001'
),
(
  'prod_bomber', 'cat_men', 'Canvas Bomber Jacket', 'canvas-bomber-jacket',
  'A chocolate-brown bomber with a cream knit cuff. Light enough for Westlands evenings, structured enough for the office commute.',
  8900, 10500, 14, 'VEL-JKT-014', '/products/bomber-jacket.jpg', true, true,
  'canvas bomber jacket brown mens outfit vel-jkt-014'
),
(
  'prod_black_dress', 'cat_women', 'Black Midi Dress', 'black-midi-dress',
  'Sleeveless midi with a clean neckline. Wear it to dinner in Kilimani or a Saturday gallery walk. Side zip, lined bodice.',
  6200, null, 18, 'VEL-DRS-008', '/products/black-dress.jpg', true, true,
  'black midi dress womens outfit vel-drs-008'
),
(
  'prod_oxfords', 'cat_mfoot', 'Black Leather Oxfords', 'black-leather-oxfords',
  'Polished leather oxfords with a stacked heel. Built for boardrooms and Sunday services. Leather lining, rubber-tipped sole.',
  7800, 9000, 16, 'VEL-SHOE-007', '/products/black-oxfords.jpg', true, false,
  'black leather oxfords formal mens footwear vel-shoe-007'
),
(
  'prod_linen', 'cat_men', 'Cream Linen Shirt', 'cream-linen-shirt',
  'Breathable linen in a warm cream. Cut slightly relaxed through the body. Tucks in, or not.',
  3200, 3800, 24, 'VEL-SHT-021', '/products/linen-shirt.jpg', true, true,
  'cream linen shirt mens outfit vel-sht-021'
),
(
  'prod_wrap', 'cat_women', 'Terracotta Wrap Dress', 'terracotta-wrap-dress',
  'A wrap midi in sun-baked terracotta. Ties at the waist, moves with you. Pairs with tan boots or sandals.',
  5500, 6400, 12, 'VEL-DRS-011', '/products/wrap-dress.jpg', true, true,
  'terracotta wrap dress womens outfit vel-drs-011'
),
(
  'prod_polo', 'cat_men', 'Navy Knit Polo', 'navy-knit-polo',
  'Fine-gauge knit polo in deep navy. Soft collar, clean placket. Works under the bomber or on its own.',
  2800, null, 30, 'VEL-POL-004', '/products/knit-polo.jpg', true, false,
  'navy knit polo shirt mens outfit vel-pol-004'
),
(
  'prod_boots', 'cat_wfoot', 'Tan Ankle Boots', 'tan-ankle-boots',
  'Suede ankle boots in warm tan. Block heel, side zip, padded collar. Made for city walking.',
  7200, 8400, 11, 'VEL-BOT-003', '/products/ankle-boots.jpg', true, true,
  'tan ankle boots suede womens footwear vel-bot-003'
),
(
  'prod_denim', 'cat_men', 'Light Wash Denim Jacket', 'light-wash-denim-jacket',
  'Classic trucker in a pale wash. Broken in from day one. Layer over the linen shirt.',
  6100, 7200, 15, 'VEL-JKT-022', '/products/denim-jacket.jpg', true, false,
  'light wash denim jacket mens outfit vel-jkt-022'
)
on conflict (id) do update set
  name = excluded.name,
  description = excluded.description,
  price = excluded.price,
  compare_at_price = excluded.compare_at_price,
  main_image_url = excluded.main_image_url,
  search_text = excluded.search_text,
  is_featured = excluded.is_featured;

insert into product_images (id, product_id, image_url, display_order, alt_text) values
  ('img_grey_1', 'prod_grey_shoe', '/products/grey-slipons.jpg', 0, 'Grey casual slip-on shoes'),
  ('img_bomb_1', 'prod_bomber', '/products/bomber-jacket.jpg', 0, 'Canvas bomber jacket'),
  ('img_dress_1', 'prod_black_dress', '/products/black-dress.jpg', 0, 'Black midi dress'),
  ('img_ox_1', 'prod_oxfords', '/products/black-oxfords.jpg', 0, 'Black leather oxfords'),
  ('img_lin_1', 'prod_linen', '/products/linen-shirt.jpg', 0, 'Cream linen shirt'),
  ('img_wrap_1', 'prod_wrap', '/products/wrap-dress.jpg', 0, 'Terracotta wrap dress'),
  ('img_polo_1', 'prod_polo', '/products/knit-polo.jpg', 0, 'Navy knit polo'),
  ('img_boot_1', 'prod_boots', '/products/ankle-boots.jpg', 0, 'Tan ankle boots'),
  ('img_den_1', 'prod_denim', '/products/denim-jacket.jpg', 0, 'Light wash denim jacket')
on conflict (id) do nothing;

insert into product_variants (id, product_id, size, sku, stock_quantity) values
  ('var_grey_s', 'prod_grey_shoe', 'S', 'VEL-SHOE-001-S', 6),
  ('var_grey_m', 'prod_grey_shoe', 'M', 'VEL-SHOE-001-M', 8),
  ('var_grey_l', 'prod_grey_shoe', 'L', 'VEL-SHOE-001-L', 9),
  ('var_grey_xl', 'prod_grey_shoe', 'XL', 'VEL-SHOE-001-XL', 5),
  ('var_bomb_s', 'prod_bomber', 'S', 'VEL-JKT-014-S', 3),
  ('var_bomb_m', 'prod_bomber', 'M', 'VEL-JKT-014-M', 5),
  ('var_bomb_l', 'prod_bomber', 'L', 'VEL-JKT-014-L', 4),
  ('var_bomb_xl', 'prod_bomber', 'XL', 'VEL-JKT-014-XL', 2),
  ('var_dress_s', 'prod_black_dress', 'S', 'VEL-DRS-008-S', 4),
  ('var_dress_m', 'prod_black_dress', 'M', 'VEL-DRS-008-M', 7),
  ('var_dress_l', 'prod_black_dress', 'L', 'VEL-DRS-008-L', 5),
  ('var_dress_xl', 'prod_black_dress', 'XL', 'VEL-DRS-008-XL', 2),
  ('var_ox_40', 'prod_oxfords', '40', 'VEL-SHOE-007-40', 3),
  ('var_ox_41', 'prod_oxfords', '41', 'VEL-SHOE-007-41', 4),
  ('var_ox_42', 'prod_oxfords', '42', 'VEL-SHOE-007-42', 5),
  ('var_ox_43', 'prod_oxfords', '43', 'VEL-SHOE-007-43', 3),
  ('var_ox_44', 'prod_oxfords', '44', 'VEL-SHOE-007-44', 1),
  ('var_lin_s', 'prod_linen', 'S', 'VEL-SHT-021-S', 6),
  ('var_lin_m', 'prod_linen', 'M', 'VEL-SHT-021-M', 8),
  ('var_lin_l', 'prod_linen', 'L', 'VEL-SHT-021-L', 7),
  ('var_lin_xl', 'prod_linen', 'XL', 'VEL-SHT-021-XL', 3),
  ('var_wrap_s', 'prod_wrap', 'S', 'VEL-DRS-011-S', 3),
  ('var_wrap_m', 'prod_wrap', 'M', 'VEL-DRS-011-M', 4),
  ('var_wrap_l', 'prod_wrap', 'L', 'VEL-DRS-011-L', 3),
  ('var_wrap_xl', 'prod_wrap', 'XL', 'VEL-DRS-011-XL', 2),
  ('var_polo_s', 'prod_polo', 'S', 'VEL-POL-004-S', 7),
  ('var_polo_m', 'prod_polo', 'M', 'VEL-POL-004-M', 9),
  ('var_polo_l', 'prod_polo', 'L', 'VEL-POL-004-L', 8),
  ('var_polo_xl', 'prod_polo', 'XL', 'VEL-POL-004-XL', 6),
  ('var_boot_36', 'prod_boots', '36', 'VEL-BOT-003-36', 2),
  ('var_boot_37', 'prod_boots', '37', 'VEL-BOT-003-37', 3),
  ('var_boot_38', 'prod_boots', '38', 'VEL-BOT-003-38', 4),
  ('var_boot_39', 'prod_boots', '39', 'VEL-BOT-003-39', 2),
  ('var_den_s', 'prod_denim', 'S', 'VEL-JKT-022-S', 4),
  ('var_den_m', 'prod_denim', 'M', 'VEL-JKT-022-M', 5),
  ('var_den_l', 'prod_denim', 'L', 'VEL-JKT-022-L', 4),
  ('var_den_xl', 'prod_denim', 'XL', 'VEL-JKT-022-XL', 2)
on conflict (id) do nothing;
