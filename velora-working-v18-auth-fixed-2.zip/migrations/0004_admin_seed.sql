-- Velora production admin bootstrap.
insert into "user" ("id", "name", "email", "emailVerified", "createdAt", "updatedAt")
values ('velora-admin-001', 'Velora Administrator', 'admin@velora.co.ke', true, now(), now())
on conflict ("email") do update set "name"=excluded."name", "emailVerified"=true, "updatedAt"=now();

insert into "account" ("id", "accountId", "providerId", "userId", "password", "createdAt", "updatedAt")
select 'velora-admin-account-001', 'admin@velora.co.ke', 'credential', id,
'e32cb516814bb0b67d090bcf37d0850c:6a7ea471bcf12d6cf137d635e043166f89152c4e35940989a0d553bade37321b41025e4655459ada500ef43a5ac48fb2499fad35189b86385561f78153ed9dea', now(), now()
from "user" where email='admin@velora.co.ke'
on conflict ("id") do update set "password"=excluded."password", "updatedAt"=now(), "userId"=excluded."userId";

insert into profiles (id, full_name, email, role, is_verified)
select id, 'Velora Administrator', email, 'admin', true from "user" where email='admin@velora.co.ke'
on conflict (id) do update set role='admin', is_verified=true, email=excluded.email, full_name=excluded.full_name, updated_at=now();
