#!/usr/bin/env node

const onVercel = Boolean(process.env.VERCEL || process.env.VERCEL_ENV);
if (!onVercel) process.exit(0);

const missing = [];
if (!process.env.DATABASE_URL?.trim()) missing.push("DATABASE_URL");
if (!process.env.BETTER_AUTH_SECRET?.trim()) missing.push("BETTER_AUTH_SECRET");
if (process.env.VITE_AUTH_ENABLED?.trim() === "false") missing.push("VITE_AUTH_ENABLED must not be false");

if (missing.length) {
  console.error("\n[velora] DEPLOYMENT STOPPED — required Vercel auth/database settings are missing:");
  for (const item of missing) console.error(`  - ${item}`);
  console.error("\nSet these in Vercel Project → Settings → Environment Variables, then redeploy.");
  console.error("DATABASE_URL must be the Neon connection string; BETTER_AUTH_SECRET must be a long random secret.");
  process.exit(1);
}

console.log("[velora] Vercel preflight passed: Neon database + Better Auth configuration detected.");
