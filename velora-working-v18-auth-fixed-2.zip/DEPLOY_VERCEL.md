# Velora — Vercel + Neon deployment

Velora uses **Vercel + Neon only**. GitHub is not required.

## One-time Vercel setup

In the Vercel project, add these Production environment variables:

```text
DATABASE_URL=<your Neon pooled connection string>
BETTER_AUTH_SECRET=<long random secret>
VITE_AUTH_ENABLED=true
VELORA_ADMIN_EMAILS=admin@velora.co.ke
```

`BETTER_AUTH_URL` may be set to:

```text
https://velora-orcin-iota.vercel.app
```

Do not put `DATABASE_URL` or `BETTER_AUTH_SECRET` in client-side `VITE_*` variables.

## Deploy

Upload this project to the existing Vercel project and deploy.

The build now **stops instead of producing a broken auth deployment** when the required Neon/Auth variables are missing.

The build also runs the database migration automatically. Migration `0004_admin_seed.sql` creates/repairs:

- `admin@velora.co.ke`
- password `VeloraAdmin#2026!`
- admin profile

## Verify before testing the UI

Open:

`/api/health`

Expected:

```json
{
  "database": "configured",
  "auth": "ready",
  "admin": "ready"
}
```

If it says `database: missing`, fix the Vercel `DATABASE_URL` variable before testing sign-in.

## PWA

Chrome controls the final installation approval. Velora captures Chrome's native install event and presents **Install Velora**. A website cannot silently install itself onto Android without Chrome's installation permission.

The service-worker cache version is bumped on every auth/PWA repair so an old phone cache does not keep serving an old build.

## WhatsApp

Cart → **Order through WhatsApp** uses:

`0745040360` / `254745040360`
