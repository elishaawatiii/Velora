import { type ReactNode, useEffect, useMemo, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  Heart,
  Home,
  Menu,
  Search,
  ShoppingBag,
  User,
  X,
  MessageCircle,
} from "lucide-react";
import { useCart } from "@/lib/cart-store";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { UserButton } from "@/lib/auth/gates";
import { whatsappHref } from "@/lib/whatsapp";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function ShopShell({
  children,
  search,
  onSearch,
  whatsappPhone,
}: {
  children: ReactNode;
  search?: string;
  onSearch?: (q: string) => void;
  whatsappPhone?: string;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const count = useCart((s) => s.items.reduce((n, l) => n + l.quantity, 0));
  const { user, isPending } = useCurrentUserState();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  const tabs = useMemo(
    () => [
      { to: "/", icon: Home, label: "Home", match: (p: string) => p === "/" },
      { to: "/cart", icon: ShoppingBag, label: "Cart", match: (p: string) => p.startsWith("/cart") || p.startsWith("/checkout") },
      { to: "/account/wishlist", icon: Heart, label: "Saved", match: (p: string) => p.includes("wishlist") },
      { to: "/account", icon: User, label: "Account", match: (p: string) => p.startsWith("/account") && !p.includes("wishlist") },
    ],
    [],
  );

  return (
    <div className="min-h-dvh bg-bg">
      <div className="mx-auto min-h-dvh max-w-lg bg-surface shadow-sm md:max-w-6xl md:bg-transparent md:shadow-none">
        <header className="sticky top-0 z-30 bg-surface/90 px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-3 backdrop-blur md:px-6">
          <div className="flex items-center gap-3">
            <button
              type="button"
              aria-label="Open menu"
              onClick={() => setMenuOpen(true)}
              className="grid size-11 place-items-center rounded-full bg-card text-fg md:hidden"
            >
              <Menu className="size-5" />
            </button>
            <Link to="/" className="flex items-center gap-2">
              <span className="grid size-9 place-items-center rounded-xl bg-primary font-bold text-primary-fg">
                V
              </span>
              <span className="text-lg font-bold tracking-tight">Velora</span>
            </Link>
            <nav className="ml-6 hidden items-center gap-5 text-sm font-medium text-muted md:flex">
              <Link to="/" className="hover:text-fg">Home</Link>
              <Link to="/shop" className="hover:text-fg">Shop</Link>
              <Link to="/category/$slug" params={{ slug: "mens-outfit" }} className="hover:text-fg">
                Men
              </Link>
              <Link to="/category/$slug" params={{ slug: "womens-outfit" }} className="hover:text-fg">
                Women
              </Link>
            </nav>
            <div className="ml-auto flex items-center gap-2">
              <Link
                to="/cart"
                aria-label="Cart"
                className="relative grid size-11 place-items-center rounded-full bg-card"
              >
                <ShoppingBag className="size-5" />
                {count > 0 && (
                  <span className="absolute top-1 right-1 grid min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-fg">
                    {count}
                  </span>
                )}
              </Link>
              <div className="hidden md:block">
                {isPending ? (
                  <div className="size-11 rounded-full bg-card" />
                ) : user ? (
                  <UserButton />
                ) : (
                  <Link to="/login">
                    <Button variant="ink" size="sm">
                      Sign in
                    </Button>
                  </Link>
                )}
              </div>
            </div>
          </div>
          <form
            className="mt-3"
            onSubmit={(e) => {
              e.preventDefault();
              const q = new FormData(e.currentTarget).get("q")?.toString() ?? "";
              onSearch?.(q);
              window.location.assign(`/shop?q=${encodeURIComponent(q)}`);
            }}
          >
            <label className="relative block">
              <Search className="pointer-events-none absolute top-1/2 left-4 size-4 -translate-y-1/2 text-faint" />
              <input
                name="q"
                defaultValue={search}
                placeholder="what are you looking for?"
                className="h-12 w-full rounded-full bg-card pr-12 pl-11 text-sm placeholder:text-faint outline-none"
              />
            </label>
          </form>
        </header>

        <main className="px-4 pb-28 md:px-6 md:pb-16">{children}</main>

        <nav className="fixed right-0 bottom-0 left-0 z-30 mx-auto max-w-lg px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:hidden">
          <div className="flex items-center justify-between rounded-full bg-surface px-3 py-2 shadow-[0_8px_30px_rgba(17,17,17,0.12)]">
            {tabs.map((tab) => {
              const active = tab.match(pathname);
              const Icon = tab.icon;
              return (
                <Link
                  key={tab.to}
                  to={tab.to}
                  aria-label={tab.label}
                  className={cn(
                    "flex h-11 items-center gap-1.5 rounded-full px-4 text-sm font-semibold",
                    active ? "bg-primary text-primary-fg" : "text-muted",
                  )}
                >
                  <Icon className="size-5" />
                  {active && tab.label}
                </Link>
              );
            })}
          </div>
        </nav>
      </div>

      {menuOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <button
            type="button"
            aria-label="Close menu"
            className="absolute inset-0 bg-ink/40"
            onClick={() => setMenuOpen(false)}
          />
          <div className="absolute top-0 left-0 flex h-full w-[82%] max-w-sm flex-col bg-surface px-5 pt-[max(1rem,env(safe-area-inset-top))] pb-8">
            <div className="flex items-center justify-between">
              <p className="text-lg font-bold">Velora</p>
              <button type="button" onClick={() => setMenuOpen(false)} className="grid size-10 place-items-center rounded-full bg-card" aria-label="Close">
                <X className="size-5" />
              </button>
            </div>
            <nav className="mt-8 flex flex-col gap-1 text-base font-medium">
              {[
                ["/", "Home"],
                ["/shop", "Shop all"],
                ["/category/mens-outfit", "Men's outfit"],
                ["/category/womens-outfit", "Woman's outfit"],
                ["/category/mens-footwear", "Men's footwear"],
                ["/account/orders", "My orders"],
                ["/admin", "Admin"],
              ].map(([href, label]) => (
                <Link
                  key={href}
                  to={href}
                  className="rounded-xl px-3 py-3 hover:bg-card"
                  onClick={() => setMenuOpen(false)}
                >
                  {label}
                </Link>
              ))}
            </nav>
            <a
              href={whatsappHref(whatsappPhone, "Hi Velora, I need help with an order.")}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-4 py-3 text-sm font-semibold text-primary-fg"
            >
              <MessageCircle className="size-4" /> WhatsApp support
            </a>
            {deferredPrompt && (
              <Button
                className="mt-3 w-full"
                variant="ink"
                onClick={async () => {
                  await deferredPrompt.prompt();
                  setDeferredPrompt(null);
                }}
              >
                Install app
              </Button>
            )}
            <div className="mt-auto pt-6">
              {user ? (
                <UserButton />
              ) : (
                <Link to="/login" onClick={() => setMenuOpen(false)}>
                  <Button variant="outline" className="w-full">Sign in</Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
}
