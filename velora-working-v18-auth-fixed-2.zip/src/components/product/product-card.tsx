import { Heart } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { formatKes } from "@/lib/money";
import type { ProductCard as ProductCardType } from "@/lib/types";
import { cn } from "@/lib/utils";

export function ProductCard({
  product,
  wished,
  onWish,
}: {
  product: ProductCardType;
  wished?: boolean;
  onWish?: (id: string) => void;
}) {
  return (
    <article className="group relative">
      <Link
        to="/product/$slug"
        params={{ slug: product.slug }}
        className="block overflow-hidden rounded-2xl bg-card"
      >
        <div className="relative aspect-[3/4] overflow-hidden">
          <img
            src={product.main_image_url}
            alt={product.name}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
            loading="lazy"
          />
        </div>
      </Link>
      {onWish && (
        <button
          type="button"
          aria-label={wished ? "Remove from wishlist" : "Save to wishlist"}
          onClick={() => onWish(product.id)}
          className="absolute top-3 right-3 grid size-9 place-items-center rounded-full bg-surface shadow-sm"
        >
          <Heart className={cn("size-4", wished ? "fill-danger text-danger" : "text-fg")} />
        </button>
      )}
      <div className="mt-2.5 px-0.5">
        <Link to="/product/$slug" params={{ slug: product.slug }} className="block">
          <p className="truncate text-sm font-semibold text-fg">{product.name}</p>
        </Link>
        <p className="mt-0.5 flex items-baseline gap-2 text-sm font-semibold tabular-nums">
          {formatKes(product.price)}
          {product.compare_at_price && product.compare_at_price > product.price && (
            <span className="text-xs font-medium text-faint line-through">
              {formatKes(product.compare_at_price)}
            </span>
          )}
        </p>
      </div>
    </article>
  );
}
