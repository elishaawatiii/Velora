import { type InputHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-12 w-full rounded-full border border-border bg-surface px-4 text-sm text-fg placeholder:text-faint",
        "outline-none focus:border-primary",
        className,
      )}
      {...props}
    />
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <span className="px-1 text-xs font-medium text-muted">{label}</span>
      {children}
    </label>
  );
}
