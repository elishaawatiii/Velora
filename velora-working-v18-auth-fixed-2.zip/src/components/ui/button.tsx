import { type ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ink" | "ghost" | "soft" | "outline";
  size?: "md" | "sm" | "icon" | "pill";
};

export function Button({ className, variant = "primary", size = "md", type = "button", ...props }: Props) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex items-center justify-center gap-2 font-semibold transition-transform duration-150 enabled:active:scale-[0.98] disabled:opacity-50",
        size === "md" && "h-12 px-5 text-sm",
        size === "sm" && "h-9 px-3 text-xs",
        size === "icon" && "size-11",
        size === "pill" && "h-11 px-4 text-sm",
        (size === "md" || size === "pill") && "rounded-full",
        size === "sm" && "rounded-full",
        size === "icon" && "rounded-full",
        variant === "primary" && "bg-primary text-primary-fg hover:bg-primary-dark",
        variant === "ink" && "bg-ink text-ink-fg",
        variant === "ghost" && "bg-surface text-fg shadow-sm",
        variant === "soft" && "bg-card text-fg",
        variant === "outline" && "border border-border bg-surface text-fg",
        className,
      )}
      {...props}
    />
  );
}
