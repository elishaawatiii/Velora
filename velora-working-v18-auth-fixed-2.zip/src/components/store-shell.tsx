import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { Download, Heart, Home, Menu, Search, ShoppingBag, SlidersHorizontal, UserRound, X } from "lucide-react";
import { useCart } from "@/lib/cart-store";
import { listCategories } from "@/lib/server/catalog";
import { toggleWishlist, wishlistIds } from "@/lib/server/wishlist";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import type { Category } from "@/lib/types";


function InstallAppButton({ compact = false }: { compact?: boolean }) {
  const [prompt, setPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [waiting, setWaiting] = useState(false);

  useEffect(() => {
    const standalone = window.matchMedia("(display-mode: standalone)").matches || Boolean((navigator as Navigator & { standalone?: boolean }).standalone);
    setInstalled(standalone);
    const onPrompt = (event: Event) => { setPrompt(event as BeforeInstallPromptEvent); };
    const onInstalled = () => { setInstalled(true); setPrompt(null); };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  if (installed) return null;

  const install = async () => {
    setWaiting(true);
    try {
      // Give the service worker one chance to become ready before prompting.
      if ("serviceWorker" in navigator) await navigator.serviceWorker.ready.catch(() => undefined);
      if (prompt) {
        await prompt.prompt();
        const result = await prompt.userChoice;
        if (result.outcome === "accepted") setInstalled(true);
        setPrompt(null);
        return;
      }
      // iOS/unsupported browsers do not expose an install prompt API. Do not
      // pretend a download exists: the OS controls installation in that case.
      const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
      const isAndroid = /android/i.test(navigator.userAgent);
      const message = isIOS
        ? "Use Share → Add to Home Screen to install Velora."
        : isAndroid
          ? "Velora is ready to install. If your browser has no install prompt, open its menu and choose Install app."
          : "Your browser does not expose a direct app-install prompt.";
      window.dispatchEvent(new CustomEvent("velora-install-help", { detail: message }));
    } finally {
      setWaiting(false);
    }
  };

  return <div className={`install-app-wrap ${compact ? "compact" : ""}`}>
    <button type="button" className="install-app-button" onClick={install} disabled={waiting}>
      <Download size={18} />
      <span>{waiting ? "Preparing install…" : "Install Velora"}</span>
    </button>
  </div>;
}

type WishlistContextValue = { ids: Set<string>; toggle: (productId: string) => Promise<boolean> };
const WishlistContext = createContext<WishlistContextValue | null>(null);

function useWishlistContext() {
  const value = useContext(WishlistContext);
  if (!value) return { ids: new Set<string>(), toggle: async () => false };
  return value;
}

export function StoreShell({ children }: { children: ReactNode }) {
  const count = useCart((s) => s.count());
  const location = useLocation();
  const { user } = useCurrentUserState();
  const [menu, setMenu] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [installHelp, setInstallHelp] = useState("");
  const pathname = location.pathname;
  const activeTab = pathname === "/" ? "home" : pathname.startsWith("/shop") || pathname.startsWith("/product/") ? "shop" : pathname.startsWith("/saved") ? "saved" : pathname.startsWith("/cart") ? "cart" : pathname.startsWith("/account") ? "account" : "";
  useEffect(() => { listCategories().then(setCategories).catch(() => undefined); }, []);
  useEffect(() => {
    let alive = true;
    if (!user) { setSavedIds(new Set()); return () => { alive = false; }; }
    wishlistIds().then(ids => { if (alive) setSavedIds(new Set(ids)); }).catch(() => { if (alive) setSavedIds(new Set()); });
    return () => { alive = false; };
  }, [user?.id]);
  useEffect(() => {
    const handler = (event: Event) => { setInstallHelp(String((event as CustomEvent<string>).detail || "")); };
    window.addEventListener("velora-install-help", handler);
    return () => window.removeEventListener("velora-install-help", handler);
  }, []);
  const wishlist = useMemo<WishlistContextValue>(() => ({
    ids: savedIds,
    toggle: async (productId: string) => {
      if (!user) { window.location.href = `/login?next=${encodeURIComponent(window.location.pathname)}`; return false; }
      const result = await toggleWishlist({ data: { productId } });
      setSavedIds(current => { const next = new Set(current); result.saved ? next.add(productId) : next.delete(productId); return next; });
      return result.saved;
    },
  }), [savedIds, user]);
  return (<WishlistContext.Provider value={wishlist}>
    <div className="store-app">
      <header className="site-header">
        <div className="header-inner">
          <button className="icon-button mobile-only" onClick={() => setMenu(true)} aria-label="Open menu"><Menu size={22}/></button>
          <Link to="/" className="brand"><span className="brand-mark">V</span><span>Velora</span></Link>
          <nav className="desktop-nav">
            <Link to="/shop">Shop</Link><Link to="/shop" search={{ sort: "new" }}>New arrivals</Link><Link to="/shop" search={{ featured: "1" }}>Featured</Link>
          </nav>
          <div className="header-actions">
            <Link className="icon-button desktop-only" to="/shop" aria-label="Search"><Search size={20}/></Link>
            <Link className="icon-button" to="/saved" aria-label="Saved"><Heart size={20}/></Link>
            <Link className="cart-button" to="/cart" aria-label="Cart"><ShoppingBag size={20}/><span>{count}</span></Link>
            <Link className="icon-button desktop-only" to="/account" aria-label="Account"><UserRound size={20}/></Link>
          </div>
        </div>
      </header>
      {menu && <div className="menu-overlay" onClick={() => setMenu(false)}><aside className="mobile-menu" onClick={(e) => e.stopPropagation()}><button className="menu-close" onClick={() => setMenu(false)}><X/></button><Link to="/" onClick={() => setMenu(false)}>Home</Link><Link to="/shop" onClick={() => setMenu(false)}>Shop</Link><Link to="/shop" search={{ sort: "new" }} onClick={() => setMenu(false)}>New arrivals</Link><Link to="/saved" onClick={() => setMenu(false)}>Saved</Link><Link to="/account" onClick={() => setMenu(false)}>Account</Link><InstallAppButton compact />
      <div className="menu-categories"><strong>Categories</strong>{categories.map(c => <Link key={c.id} to="/shop" search={{ category: c.slug }}>{c.name}</Link>)}</div></aside></div>}
      {children}
      <nav className="bottom-nav mobile-only" aria-label="Primary mobile navigation">
        {[
          { id: "home", to: "/", label: "Home", icon: Home },
          { id: "shop", to: "/shop", label: "Shop", icon: Search },
          { id: "saved", to: "/saved", label: "Saved", icon: Heart },
          { id: "cart", to: "/cart", label: "Cart", icon: ShoppingBag },
          { id: "account", to: "/account", label: "Account", icon: UserRound },
        ].map(({ id, to, label, icon: Icon }) => {
          const active = activeTab === id;
          return <Link key={id} to={to} className={active ? "active" : ""} aria-current={active ? "page" : undefined}>
            <span className="bottom-nav-icon"><Icon strokeWidth={active ? 2.5 : 2} /></span>
            <small>{label}{id === "cart" && count ? ` (${count})` : ""}</small>
          </Link>;
        })}
      </nav>
      {installHelp && <div className="install-toast" role="status" onClick={() => setInstallHelp("")}>{installHelp}</div>}
    </div>
  </WishlistContext.Provider>
  );
}

export function SearchBar({ defaultValue = "" }: { defaultValue?: string }) {
  return <form className="search-bar" action="/shop"><Search size={19}/><input name="q" defaultValue={defaultValue} placeholder="what are you looking for?" aria-label="Search products"/><button type="submit" aria-label="Search"><SlidersHorizontal size={19}/></button></form>;
}

export function ProductCard({ product }: { product: import("@/lib/types").ProductCard }) {
  const { ids, toggle } = useWishlistContext();
  const [saving, setSaving] = useState(false);
  const saved = ids.has(product.id);
  return <article className="product-card">
    <div className="product-image-wrap"><Link to={`/product/${product.slug}`}><img src={product.main_image_url} alt={product.name}/></Link>{product.compare_at_price && <span className="sale-tag">SALE</span>}<button type="button" className={`heart-float ${saved ? "saved" : ""}`} disabled={saving} onClick={async () => { setSaving(true); try { await toggle(product.id); } catch { window.location.href=`/login?next=${encodeURIComponent(window.location.pathname)}`; } finally { setSaving(false); } }} aria-label={saved ? "Remove from saved items" : "Save product"} aria-pressed={saved}><Heart size={18} fill={saved ? "currentColor" : "none"}/></button></div>
    <Link to={`/product/${product.slug}`} className="product-info"><span className="eyebrow">{product.category_name}</span><h3>{product.name}</h3><div className="price-row"><strong>KSh {product.price.toLocaleString("en-KE")}</strong>{product.compare_at_price && <del>KSh {product.compare_at_price.toLocaleString("en-KE")}</del>}</div>{product.low_stock && <small className="stock-note">Only {product.stock_quantity} left</small>}</Link>
  </article>
}

export function ProductGrid({ products }: { products: import("@/lib/types").ProductCard[] }) {
  if (!products.length) return <div className="empty-state"><h3>No products found</h3><p>Try another search or category.</p><Link className="button primary" to="/shop">View all products</Link></div>;
  return <div className="product-grid">{products.map(p => <ProductCard key={p.id} product={p}/>)}</div>;
}
