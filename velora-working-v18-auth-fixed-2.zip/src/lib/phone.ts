/**
 * Kenyan phone handling. Internally we store 2547XXXXXXXX / 2541XXXXXXXX.
 * Accepts 07, 01, 254, +254. Invalid numbers return null — never silent coerce.
 */

export function digitsOnly(input: string): string {
  return input.replace(/\D/g, "");
}

export function normalizeKenyanPhone(input: string): string | null {
  let d = digitsOnly(input);
  if (d.startsWith("0") && d.length === 10 && /^0[17]\d{8}$/.test(d)) {
    d = `254${d.slice(1)}`;
  } else if (d.length === 9 && /^[17]\d{8}$/.test(d)) {
    d = `254${d}`;
  }
  if (/^254[17]\d{8}$/.test(d)) return d;
  return null;
}

export function formatKenyanPhone(input: string): string {
  const n = normalizeKenyanPhone(input);
  if (!n) return input.trim();
  return `0${n.slice(3, 4)} ${n.slice(4, 7)} ${n.slice(7)}`;
}

export function isMpesaCapable(input: string): boolean {
  const n = normalizeKenyanPhone(input);
  return Boolean(n && n.startsWith("2547"));
}
