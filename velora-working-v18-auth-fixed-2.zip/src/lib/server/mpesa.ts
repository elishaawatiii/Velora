/**
 * Daraja STK Push. Secrets stay on the server.
 * MPESA_CONSUMER_KEY, MPESA_CONSUMER_SECRET, MPESA_SHORTCODE, MPESA_PASSKEY,
 * MPESA_CALLBACK_URL (optional), MPESA_ENV=sandbox|production
 */

import { getSql } from "@/lib/db";
import { newId } from "@/lib/utils";

export function mpesaConfigured(): boolean {
  return Boolean(
    process.env.MPESA_CONSUMER_KEY?.trim() &&
      process.env.MPESA_CONSUMER_SECRET?.trim() &&
      process.env.MPESA_SHORTCODE?.trim() &&
      process.env.MPESA_PASSKEY?.trim(),
  );
}

function darajaHost(): string {
  return process.env.MPESA_ENV === "production"
    ? "https://api.safaricom.co.ke"
    : "https://sandbox.safaricom.co.ke";
}

function timestamp(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

async function accessToken(): Promise<string> {
  const key = process.env.MPESA_CONSUMER_KEY!;
  const secret = process.env.MPESA_CONSUMER_SECRET!;
  const auth = Buffer.from(`${key}:${secret}`).toString("base64");
  const res = await fetch(
    `${darajaHost()}/oauth/v1/generate?grant_type=client_credentials`,
    { headers: { Authorization: `Basic ${auth}` } },
  );
  if (!res.ok) throw new Error("Could not reach M-Pesa. Try again in a moment.");
  const json = (await res.json()) as { access_token?: string };
  if (!json.access_token) throw new Error("M-Pesa did not issue an access token.");
  return json.access_token;
}

export async function initiateStkPush(opts: {
  phone: string;
  amount: number;
  accountRef: string;
  description: string;
}): Promise<{ checkoutRequestId: string; merchantRequestId: string; customerMessage: string }> {
  const shortcode = process.env.MPESA_SHORTCODE!;
  const passkey = process.env.MPESA_PASSKEY!;
  const ts = timestamp();
  const password = Buffer.from(`${shortcode}${passkey}${ts}`).toString("base64");
  const callbackUrl =
    process.env.MPESA_CALLBACK_URL?.trim() ||
    "https://example.invalid/api/mpesa/callback";
  const token = await accessToken();
  const res = await fetch(`${darajaHost()}/mpesa/stkpush/v1/processrequest`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      BusinessShortCode: shortcode,
      Password: password,
      Timestamp: ts,
      TransactionType: "CustomerPayBillOnline",
      Amount: opts.amount,
      PartyA: opts.phone,
      PartyB: shortcode,
      PhoneNumber: opts.phone,
      CallBackURL: callbackUrl,
      AccountReference: opts.accountRef.slice(0, 12),
      TransactionDesc: opts.description.slice(0, 13),
    }),
  });
  const json = (await res.json()) as {
    ResponseCode?: string;
    CustomerMessage?: string;
    CheckoutRequestID?: string;
    MerchantRequestID?: string;
    errorMessage?: string;
  };
  if (json.ResponseCode !== "0" || !json.CheckoutRequestID) {
    throw new Error(json.errorMessage || json.CustomerMessage || "M-Pesa could not start the payment.");
  }
  return {
    checkoutRequestId: json.CheckoutRequestID,
    merchantRequestId: json.MerchantRequestID ?? "",
    customerMessage: json.CustomerMessage || "Check your phone for the M-Pesa PIN prompt.",
  };
}

type StkCallback = {
  Body?: {
    stkCallback?: {
      MerchantRequestID?: string;
      CheckoutRequestID?: string;
      ResultCode?: number;
      ResultDesc?: string;
      CallbackMetadata?: {
        Item?: { Name: string; Value?: string | number }[];
      };
    };
  };
};

export async function processMpesaCallback(payload: StkCallback): Promise<void> {
  const cb = payload?.Body?.stkCallback;
  if (!cb?.CheckoutRequestID) return;
  const sql = await getSql();
  const pays = await sql.query<{
    id: string;
    order_id: string;
    user_id: string;
    status: string;
    amount: number;
  }>(`select id, order_id, user_id, status, amount from payments where checkout_request_id = $1`, [
    cb.CheckoutRequestID,
  ]);
  const pay = pays[0];
  if (!pay) return;
  if (pay.status === "paid") return;

  const ok = cb.ResultCode === 0;
  const items = cb.CallbackMetadata?.Item ?? [];
  const receipt = items.find((i) => i.Name === "MpesaReceiptNumber")?.Value;
  const paidAmount = Number(items.find((i) => i.Name === "Amount")?.Value ?? 0);

  if (!ok) {
    await sql.query(
      `update payments set status = $1, result_code = $2, result_desc = $3, updated_at = now() where id = $4`,
      [cb.ResultCode === 1032 ? "cancelled" : "failed", String(cb.ResultCode ?? ""), cb.ResultDesc ?? "", pay.id],
    );
    await sql.query(
      `update orders set payment_status = 'failed', updated_at = now() where id = $1 and payment_status = 'initiated'`,
      [pay.order_id],
    );
    return;
  }

  if (paidAmount && paidAmount !== Number(pay.amount)) {
    await sql.query(
      `update payments set status = 'failed', result_desc = $1, updated_at = now() where id = $2`,
      ["Amount mismatch — not marked paid", pay.id],
    );
    return;
  }

  const claimed = await sql.query<{ id: string }>(
    `update payments
     set status = 'paid', receipt_number = $1, result_code = '0', result_desc = $2, updated_at = now()
     where id = $3 and status <> 'paid'
     returning id`,
    [receipt != null ? String(receipt) : null, cb.ResultDesc ?? "Success", pay.id],
  );
  if (!claimed[0]) return;
  await sql.query(
    `update orders
     set payment_status = 'paid', status = 'confirmed', updated_at = now()
     where id = $1`,
    [pay.order_id],
  );

  const itemsRows = await sql.query<{
    product_id: string | null;
    variant_id: string | null;
    quantity: number;
  }>(`select product_id, variant_id, quantity from order_items where order_id = $1`, [pay.order_id]);
  for (const line of itemsRows) {
    if (line.variant_id) {
      await sql.query(
        `update product_variants
         set stock_quantity = greatest(stock_quantity - $1, 0)
         where id = $2`,
        [line.quantity, line.variant_id],
      );
    } else if (line.product_id) {
      await sql.query(
        `update products set stock_quantity = greatest(stock_quantity - $1, 0) where id = $2`,
        [line.quantity, line.product_id],
      );
    }
  }
  await sql.query(
    `insert into notifications (id, user_id, title, body, link)
     values ($1, $2, $3, $4, $5)`,
    [
      newId("nt"),
      pay.user_id,
      "Payment received",
      "M-Pesa payment confirmed. We are preparing your order.",
      `/account/orders/${pay.order_id}`,
    ],
  );
}
