import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { requireAdmin } from "./me";
import { newId } from "@/lib/utils";

const productSchema = z.object({
  category: z.string().min(1),
  name: z.string().min(2).max(80),
  slug: z.string().min(2).max(100),
  description: z.string().max(2000).default(""),
  price: z.coerce.number().int().min(0),
  compare_at_price: z.coerce.number().int().min(0).nullable().default(null),
  stock_quantity: z.coerce.number().int().min(0).default(0),
  sku: z.string().min(2).max(40),
  main_image_url: z.string().min(1),
  is_active: z.preprocess((v) => v === true || v === "true" || v === 1 || v === "1", z.boolean()).default(true),
  is_featured: z.preprocess((v) => v === true || v === "true" || v === 1 || v === "1", z.boolean()).default(false),
});

export const adminImportProducts = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ products: z.array(productSchema).min(1).max(1000) }))
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const categories = await sql<{ id: string; name: string; slug: string }>`select id,name,slug from categories`;
    const byKey = new Map(categories.flatMap((c) => [[c.id.toLowerCase(), c], [c.name.toLowerCase(), c], [c.slug.toLowerCase(), c]]));
    let imported = 0;
    const errors: { row: number; message: string }[] = [];

    for (let i = 0; i < data.products.length; i++) {
      const p = data.products[i];
      const category = byKey.get(p.category.toLowerCase());
      if (!category) { errors.push({ row: i + 2, message: `Category not found: ${p.category}` }); continue; }
      try {
        const id = newId("prod");
        const search = `${p.name} ${p.description} ${p.sku}`.toLowerCase();
        await sql`
          insert into products (id,category_id,name,slug,description,price,compare_at_price,stock_quantity,sku,main_image_url,is_active,is_featured,search_text)
          values (${id},${category.id},${p.name},${p.slug},${p.description},${p.price},${p.compare_at_price},${p.stock_quantity},${p.sku},${p.main_image_url},${p.is_active},${p.is_featured},${search})
          on conflict (sku) do update set
            category_id=excluded.category_id,name=excluded.name,slug=excluded.slug,description=excluded.description,price=excluded.price,
            compare_at_price=excluded.compare_at_price,stock_quantity=excluded.stock_quantity,main_image_url=excluded.main_image_url,
            is_active=excluded.is_active,is_featured=excluded.is_featured,search_text=excluded.search_text,updated_at=now()
        `;
        imported++;
      } catch (e) { errors.push({ row: i + 2, message: e instanceof Error ? e.message : "Import failed" }); }
    }
    return { imported, failed: errors.length, errors };
  });
