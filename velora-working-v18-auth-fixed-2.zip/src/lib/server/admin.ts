import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { requireAdmin } from "./me";
import { newId } from "@/lib/utils";
import { normalizeKenyanPhone } from "@/lib/phone";

export const adminDashboard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const [orders, revenue, pending, paid, products, low, customers] = await Promise.all([
      sql<{ n: number }>`select count(*)::int as n from orders`,
      sql<{ n: number }>`select coalesce(sum(total),0)::int as n from orders where payment_status = 'paid'`,
      sql<{ n: number }>`select count(*)::int as n from orders where status = 'pending'`,
      sql<{ n: number }>`select count(*)::int as n from orders where payment_status = 'paid'`,
      sql<{ n: number }>`select count(*)::int as n from products`,
      sql<{ n: number }>`select count(*)::int as n from products where stock_quantity <= low_stock_threshold`,
      sql<{ n: number }>`select count(*)::int as n from profiles`,
    ]);
    const recent = await sql<{
      id: string;
      order_number: string;
      total: number;
      status: string;
      payment_status: string;
      customer_name: string;
      created_at: string;
    }>`
      select id, order_number, total, status, payment_status, customer_name,
             created_at::text as created_at
      from orders order by created_at desc limit 8
    `;
    return {
      totalOrders: orders[0]?.n ?? 0,
      revenue: revenue[0]?.n ?? 0,
      pendingOrders: pending[0]?.n ?? 0,
      paidOrders: paid[0]?.n ?? 0,
      products: products[0]?.n ?? 0,
      lowStock: low[0]?.n ?? 0,
      customers: customers[0]?.n ?? 0,
      recent: recent.map((r) => ({ ...r, total: Number(r.total) })),
    };
  });

export const adminListOrders = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      q: z.string().optional(),
      status: z.string().optional(),
    }),
  )
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const q = data.q?.trim() || null;
    const status = data.status?.trim() || null;
    const rows = await sql.query<{
      id: string;
      order_number: string;
      total: number;
      status: string;
      payment_status: string;
      payment_method: string;
      customer_name: string;
      customer_phone: string;
      created_at: string;
    }>(
      `select id, order_number, total, status, payment_status, payment_method,
              customer_name, customer_phone, created_at::text as created_at
       from orders
       where ($1::text is null or order_number ilike '%' || $1 || '%' or customer_name ilike '%' || $1 || '%' or customer_phone ilike '%' || $1 || '%')
         and ($2::text is null or status = $2)
       order by created_at desc
       limit 80`,
      [q, status],
    );
    return rows.map((r) => ({ ...r, total: Number(r.total) }));
  });

export const adminGetOrder = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const rows = await sql.query<Record<string, unknown>>(
      `select * from orders where id = $1`,
      [data.id],
    );
    if (!rows[0]) return null;
    const items = await sql.query(
      `select * from order_items where order_id = $1`,
      [data.id],
    );
    const payments = await sql.query(
      `select id, amount, status, receipt_number, phone_number, result_desc, created_at::text as created_at
       from payments where order_id = $1 order by created_at desc`,
      [data.id],
    );
    return { order: rows[0], items, payments };
  });

export const adminUpdateOrderStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      id: z.string(),
      status: z.enum(["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]),
    }),
  )
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    await sql`
      update orders set status = ${data.status}, updated_at = now() where id = ${data.id}
    `;
    const order = await sql<{ user_id: string; order_number: string }>`
      select user_id, order_number from orders where id = ${data.id}
    `;
    if (order[0]) {
      await sql`
        insert into notifications (id, user_id, title, body, link)
        values (
          ${newId("nt")}, ${order[0].user_id}, ${"Order " + order[0].order_number},
          ${`Status updated to ${data.status}.`}, ${"/account/orders/" + data.id}
        )
      `;
    }
    return { ok: true };
  });

export const adminListProducts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    return sql<{
      id: string;
      name: string;
      slug: string;
      sku: string;
      price: number;
      stock_quantity: number;
      is_active: boolean;
      is_featured: boolean;
      category_name: string | null;
    }>`
      select p.id, p.name, p.slug, p.sku, p.price, p.stock_quantity, p.is_active, p.is_featured,
             c.name as category_name
      from products p
      left join categories c on c.id = p.category_id
      order by p.created_at desc
    `;
  });

export const adminSaveProduct = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      id: z.string().optional(),
      category_id: z.string(),
      name: z.string().min(2).max(80),
      slug: z.string().min(2).max(80),
      description: z.string().max(2000),
      price: z.number().int().min(0),
      compare_at_price: z.number().int().min(0).nullable(),
      stock_quantity: z.number().int().min(0),
      sku: z.string().min(2).max(40),
      main_image_url: z.string().min(1),
      is_active: z.boolean(),
      is_featured: z.boolean(),
    }),
  )
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const id = data.id ?? newId("prod");
    const search = `${data.name} ${data.description} ${data.sku}`.toLowerCase();
    await sql.query(
      `insert into products (
         id, category_id, name, slug, description, price, compare_at_price,
         stock_quantity, sku, main_image_url, is_active, is_featured, search_text
       ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
       on conflict (id) do update set
         category_id = excluded.category_id,
         name = excluded.name,
         slug = excluded.slug,
         description = excluded.description,
         price = excluded.price,
         compare_at_price = excluded.compare_at_price,
         stock_quantity = excluded.stock_quantity,
         sku = excluded.sku,
         main_image_url = excluded.main_image_url,
         is_active = excluded.is_active,
         is_featured = excluded.is_featured,
         search_text = excluded.search_text,
         updated_at = now()`,
      [
        id,
        data.category_id,
        data.name,
        data.slug,
        data.description,
        data.price,
        data.compare_at_price,
        data.stock_quantity,
        data.sku,
        data.main_image_url,
        data.is_active,
        data.is_featured,
        search,
      ],
    );
    return { id };
  });

export const adminListCustomers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    return sql<{
      id: string;
      full_name: string | null;
      email: string | null;
      phone: string | null;
      role: string;
      created_at: string;
    }>`
      select id, full_name, email, phone, role, created_at::text as created_at
      from profiles
      order by created_at desc
      limit 100
    `;
  });

export const adminListCategories = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    return sql`select id, name, slug, image_url, is_active, display_order from categories order by display_order`;
  });

export const adminSaveCategory = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      id: z.string().optional(),
      name: z.string().min(2).max(60),
      slug: z.string().min(2).max(60),
      image_url: z.string().optional(),
      is_active: z.boolean(),
    }),
  )
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const id = data.id ?? newId("cat");
    await sql.query(
      `insert into categories (id, name, slug, image_url, is_active)
       values ($1,$2,$3,$4,$5)
       on conflict (id) do update set name = excluded.name, slug = excluded.slug,
         image_url = excluded.image_url, is_active = excluded.is_active, updated_at = now()`,
      [id, data.name, data.slug, data.image_url ?? null, data.is_active],
    );
    return { id };
  });

export const adminSaveZone = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      id: z.string().optional(),
      name: z.string().min(2),
      fee: z.number().int().min(0),
      eta_text: z.string().min(2),
      is_active: z.boolean(),
    }),
  )
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const id = data.id ?? newId("zone");
    await sql.query(
      `insert into delivery_zones (id, name, fee, eta_text, is_active)
       values ($1,$2,$3,$4,$5)
       on conflict (id) do update set name = excluded.name, fee = excluded.fee,
         eta_text = excluded.eta_text, is_active = excluded.is_active`,
      [id, data.name, data.fee, data.eta_text, data.is_active],
    );
    return { id };
  });

export const adminSaveSettings = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      store_name: z.string().min(2),
      store_tagline: z.string(),
      whatsapp_phone: z.string(),
      support_email: z.string(),
    }),
  )
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const phone = normalizeKenyanPhone(data.whatsapp_phone) ?? data.whatsapp_phone.replace(/\D/g, "");
    const sql = await getSql();
    for (const [key, value] of Object.entries({
      store_name: data.store_name,
      store_tagline: data.store_tagline,
      whatsapp_phone: phone,
      support_email: data.support_email,
    })) {
      await sql`insert into store_settings (key, value) values (${key}, ${value})
                on conflict (key) do update set value = excluded.value`;
    }
    return { ok: true };
  });
