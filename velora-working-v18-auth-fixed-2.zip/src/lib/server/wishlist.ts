import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import type { ProductCard } from "@/lib/types";
import { upsertProfile } from "./me";

export const listWishlist = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ProductCard[]> => {
    const sql = await getSql();
    const rows = await sql<ProductCard & { low_stock_threshold: number }>`
      select
        p.id, p.name, p.slug, p.price, p.compare_at_price, p.main_image_url, p.sku,
        p.category_id, p.stock_quantity, p.is_featured,
        c.name as category_name, c.slug as category_slug,
        p.low_stock_threshold
      from favorites f
      join products p on p.id = f.product_id
      left join categories c on c.id = p.category_id
      where f.user_id = ${context.userId} and p.is_active = true
      order by f.created_at desc
    `;
    return rows.map((r) => ({
      ...r,
      price: Number(r.price),
      compare_at_price: r.compare_at_price == null ? null : Number(r.compare_at_price),
      stock_quantity: Number(r.stock_quantity),
      low_stock: Number(r.stock_quantity) > 0 && Number(r.stock_quantity) <= 5,
    }));
  });

export const toggleWishlist = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ productId: z.string() }))
  .handler(async ({ context, data }): Promise<{ saved: boolean }> => {
    await upsertProfile(context.userId);
    const sql = await getSql();
    const existing = await sql<{ product_id: string }>`
      select product_id from favorites
      where user_id = ${context.userId} and product_id = ${data.productId}
    `;
    if (existing[0]) {
      await sql`
        delete from favorites
        where user_id = ${context.userId} and product_id = ${data.productId}
      `;
      return { saved: false };
    }
    await sql`
      insert into favorites (user_id, product_id)
      values (${context.userId}, ${data.productId})
    `;
    return { saved: true };
  });

export const wishlistIds = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<string[]> => {
    const sql = await getSql();
    const rows = await sql<{ product_id: string }>`
      select product_id from favorites where user_id = ${context.userId}
    `;
    return rows.map((r) => r.product_id);
  });
