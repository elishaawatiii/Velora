import type { Category, DeliveryZone, ProductCard, ProductDetail, ProductImage, ProductVariant, StoreSettings } from "@/lib/types";

export const FALLBACK_CATEGORIES: Category[] = [
  { id: "cat_men", name: "Men's outfit", slug: "mens-outfit", description: "Jackets, shirts and everyday menswear.", image_url: "/products/bomber-jacket.jpg", is_active: true, display_order: 1 },
  { id: "cat_women", name: "Woman's outfit", slug: "womens-outfit", description: "Dresses and ready-to-wear for women.", image_url: "/products/black-dress.jpg", is_active: true, display_order: 2 },
  { id: "cat_mfoot", name: "Men's footwear", slug: "mens-footwear", description: "Casual and formal shoes for men.", image_url: "/products/black-oxfords.jpg", is_active: true, display_order: 3 },
  { id: "cat_wfoot", name: "Women's footwear", slug: "womens-footwear", description: "Boots and everyday shoes for women.", image_url: "/products/ankle-boots.jpg", is_active: true, display_order: 4 },
];

const raw = [
  ["prod_grey_shoe","cat_mfoot","Grey Casual shoe","grey-casual-shoe",4500,5200,28,"VEL-SHOE-001","/products/grey-slipons.jpg",true,"Soft canvas slip-ons with a clean white sole. Easy with jeans, chinos or a weekend set. Cushioned insole, unlined for Nairobi heat."],
  ["prod_bomber","cat_men","Canvas Bomber Jacket","canvas-bomber-jacket",8900,10500,14,"VEL-JKT-014","/products/bomber-jacket.jpg",true,"A chocolate-brown bomber with a cream knit cuff. Light enough for Westlands evenings, structured enough for the office commute."],
  ["prod_black_dress","cat_women","Black Midi Dress","black-midi-dress",6200,null,18,"VEL-DRS-008","/products/black-dress.jpg",true,"Sleeveless midi with a clean neckline. Wear it to dinner in Kilimani or a Saturday gallery walk. Side zip, lined bodice."],
  ["prod_oxfords","cat_mfoot","Black Leather Oxfords","black-leather-oxfords",7800,9000,16,"VEL-SHOE-007","/products/black-oxfords.jpg",false,"Polished leather oxfords with a stacked heel. Built for boardrooms and Sunday services. Leather lining, rubber-tipped sole."],
  ["prod_linen","cat_men","Cream Linen Shirt","cream-linen-shirt",3200,3800,24,"VEL-SHT-021","/products/linen-shirt.jpg",true,"Breathable linen in a warm cream. Cut slightly relaxed through the body. Tucks in, or not."],
  ["prod_wrap","cat_women","Terracotta Wrap Dress","terracotta-wrap-dress",5500,6400,12,"VEL-DRS-011","/products/wrap-dress.jpg",true,"A wrap midi in sun-baked terracotta. Ties at the waist, moves with you. Pairs with tan boots or sandals."],
  ["prod_polo","cat_men","Navy Knit Polo","navy-knit-polo",2800,null,30,"VEL-POL-004","/products/knit-polo.jpg",false,"Fine-gauge knit polo in deep navy. Soft collar, clean placket. Works under the bomber or on its own."],
  ["prod_boots","cat_wfoot","Tan Ankle Boots","tan-ankle-boots",7200,8400,11,"VEL-BOT-003","/products/ankle-boots.jpg",true,"Suede ankle boots in warm tan. Block heel, side zip, padded collar. Made for city walking."],
  ["prod_denim","cat_men","Light Wash Denim Jacket","light-wash-denim-jacket",6100,7200,15,"VEL-JKT-022","/products/denim-jacket.jpg",false,"Classic trucker in a pale wash. Broken in from day one. Layer over the linen shirt."],
] as const;

const sizes: Record<string, string[]> = {
  prod_grey_shoe: ["S","M","L","XL"], prod_bomber: ["S","M","L","XL"], prod_black_dress: ["S","M","L","XL"],
  prod_oxfords: ["40","41","42","43","44"], prod_linen: ["S","M","L","XL"], prod_wrap: ["S","M","L","XL"],
  prod_polo: ["S","M","L","XL"], prod_boots: ["36","37","38","39"], prod_denim: ["S","M","L","XL"],
};

export const FALLBACK_PRODUCTS: ProductCard[] = raw.map(([id, category_id, name, slug, price, compare_at_price, stock_quantity, sku, main_image_url, is_featured]) => {
  const category = FALLBACK_CATEGORIES.find((c) => c.id === category_id)!;
  return { id, category_id, name, slug, price, compare_at_price, stock_quantity, sku, main_image_url, category_name: category.name, category_slug: category.slug, is_featured, low_stock: stock_quantity > 0 && stock_quantity <= 5 };
});

export const FALLBACK_DETAILS: ProductDetail[] = raw.map(([id, category_id, name, slug, price, compare_at_price, stock_quantity, sku, main_image_url, is_featured, description]) => {
  const card = FALLBACK_PRODUCTS.find((p) => p.id === id)!;
  const variants: ProductVariant[] = sizes[id].map((size, i) => ({ id: `${id}-v-${i + 1}`, product_id: id, size, color: null, sku: `${sku}-${size}`, price: null, stock_quantity: Math.max(1, Math.floor(stock_quantity / sizes[id].length)) }));
  const image: ProductImage = { id: `${id}-image`, image_url: main_image_url, display_order: 0, alt_text: name };
  return { ...card, description, low_stock_threshold: 5, is_active: true, images: [image], variants };
});

export const FALLBACK_SETTINGS: StoreSettings = { store_name: "Velora", store_tagline: "Everyday fashion, delivered across Kenya", whatsapp_phone: "254711000000", support_email: "hello@velora.shop" };
export const FALLBACK_DELIVERY_ZONES: DeliveryZone[] = [
  { id: "zone_cbd", name: "Nairobi CBD", fee: 200, eta_text: "Same day – next day" },
  { id: "zone_nairobi", name: "Nairobi (other)", fee: 350, eta_text: "1–2 days" },
  { id: "zone_metro", name: "Kiambu / Machakos / Kajiado", fee: 500, eta_text: "2–3 days" },
  { id: "zone_kenya", name: "Rest of Kenya", fee: 800, eta_text: "3–5 days" },
];
