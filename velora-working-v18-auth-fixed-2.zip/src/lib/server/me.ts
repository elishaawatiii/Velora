import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { normalizeKenyanPhone } from "@/lib/phone";
import type { StoreProfile } from "@/lib/types";

function adminEmails(): string[] {
  return (process.env.VELORA_ADMIN_EMAILS ?? 'admin@velora.co.ke').split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);
}

export async function upsertProfile(userId: string, email?: string | null, name?: string | null) {
  const sql = await getSql();
  await sql`
    insert into profiles (id, email, full_name, role)
    values (${userId}, ${email ?? null}, ${name ?? null}, 'customer')
    on conflict (id) do update set
      email = coalesce(excluded.email, profiles.email),
      full_name = coalesce(excluded.full_name, profiles.full_name),
      updated_at = now()
  `;
}

export async function getProfile(userId: string): Promise<StoreProfile | null> {
  const sql = await getSql();
  const rows = await sql<StoreProfile>`
    select id, full_name, email, phone, role from profiles where id = ${userId}
  `;
  return rows[0] ?? null;
}

export async function requireAdmin(userId: string): Promise<StoreProfile> {
  const profile = await getProfile(userId);
  if (!profile || profile.role !== "admin") {
    const err = new Error("Forbidden");
    (err as Error & { status?: number }).status = 403;
    throw err;
  }
  return profile;
}

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<StoreProfile> => {
    const { getSessionUser } = await import("@/lib/auth/verify.server");
    const user = await getSessionUser(context.bearerToken);
    await upsertProfile(context.userId, user?.email ?? null, null);
    const allowed = user?.email && adminEmails().includes(user.email.toLowerCase());
    if (allowed) {
      const sql = await getSql();
      await sql`update profiles set role = 'admin', updated_at = now() where id = ${context.userId}`;
    }
    const profile = await getProfile(context.userId);
    if (!profile) throw new Error("Profile missing");
    return profile;
  });

export const updateMyProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      full_name: z.string().min(2).max(80),
      phone: z.string().min(9).max(20),
    }),
  )
  .handler(async ({ context, data }): Promise<StoreProfile> => {
    const phone = normalizeKenyanPhone(data.phone);
    if (!phone) throw new Error("Enter a valid Kenyan phone number (07… or 2547…).");
    await upsertProfile(context.userId);
    const sql = await getSql();
    await sql`
      update profiles
      set full_name = ${data.full_name.trim()}, phone = ${phone}, updated_at = now()
      where id = ${context.userId}
    `;
    const profile = await getProfile(context.userId);
    if (!profile) throw new Error("Profile missing");
    return profile;
  });

export const claimStoreIfEmpty = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<{ role: "admin" | "customer"; claimed: boolean }> => {
    const { getSessionUser } = await import("@/lib/auth/verify.server");
    const user = await getSessionUser();
    const allowed = Boolean(user?.email && adminEmails().includes(user.email.toLowerCase()));
    await upsertProfile(context.userId, user?.email ?? null, user?.name ?? null);
    if (!allowed) {
      const me = await getProfile(context.userId);
      return { role: me?.role === "admin" ? "admin" : "customer", claimed: false };
    }
    const sql = await getSql();
    const admins = await sql<{ n: number }>`select count(*)::int as n from profiles where role = 'admin'`;
    if ((admins[0]?.n ?? 0) > 0) {
      const me = await getProfile(context.userId);
      return { role: me?.role === "admin" ? "admin" : "customer", claimed: me?.role === "admin" };
    }
    await sql`update profiles set role = 'admin', updated_at = now() where id = ${context.userId}`;
    return { role: "admin", claimed: true };
  });
