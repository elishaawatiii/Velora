import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { FALLBACK_CATEGORIES, FALLBACK_DELIVERY_ZONES, FALLBACK_DETAILS, FALLBACK_PRODUCTS, FALLBACK_SETTINGS } from "@/lib/server/catalog-fallback";
import type {
  Category,
  DeliveryZone,
  ProductCard,
  ProductDetail,
  ProductImage,
  ProductVariant,
  StoreSettings,
} from "@/lib/types";

const CARD_SELECT = `
  p.id, p.name, p.slug, p.price, p.compare_at_price, p.main_image_url, p.sku,
  p.category_id, p.stock_quantity, p.is_featured, p.low_stock_threshold,
  c.name as category_name, c.slug as category_slug
`;

type CardRow = {
  id: string;
  name: string;
  slug: string;
  price: number;
  compare_at_price: number | null;
  main_image_url: string;
  sku: string;
  category_id: string;
  stock_quantity: number;
  is_featured: boolean;
  low_stock_threshold: number;
  category_name: string | null;
  category_slug: string | null;
};

function toCard(r: CardRow): ProductCard {
  return {
    id: r.id,
    name: r.name,
    slug: r.slug,
    price: Number(r.price),
    compare_at_price: r.compare_at_price == null ? null : Number(r.compare_at_price),
    main_image_url: r.main_image_url,
    sku: r.sku,
    category_id: r.category_id,
    category_name: r.category_name,
    category_slug: r.category_slug,
    stock_quantity: Number(r.stock_quantity),
    is_featured: Boolean(r.is_featured),
    low_stock: Number(r.stock_quantity) > 0 && Number(r.stock_quantity) <= Number(r.low_stock_threshold),
  };
}

export const getStoreSettings = createServerFn({ method: "GET" }).handler(
  async (): Promise<StoreSettings> => {
    try {
      const sql = await getSql();
      const rows = await sql<{ key: string; value: string }>`select key, value from store_settings`;
      const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
      return {
        store_name: map.store_name ?? FALLBACK_SETTINGS.store_name,
        store_tagline: map.store_tagline ?? FALLBACK_SETTINGS.store_tagline,
        whatsapp_phone: map.whatsapp_phone ?? FALLBACK_SETTINGS.whatsapp_phone,
        support_email: map.support_email ?? FALLBACK_SETTINGS.support_email,
      };
    } catch {
      return FALLBACK_SETTINGS;
    }
  },
);

export const listCategories = createServerFn({ method: "GET" }).handler(
  async (): Promise<Category[]> => {
    try {
      const sql = await getSql();
      const rows = await sql<Category>`
        select id, name, slug, description, image_url, is_active, display_order
        from categories
        where is_active = true
        order by display_order, name
      `;
      return rows.length ? rows : FALLBACK_CATEGORIES;
    } catch {
      return FALLBACK_CATEGORIES;
    }
  },
);

export const listDeliveryZones = createServerFn({ method: "GET" }).handler(
  async (): Promise<DeliveryZone[]> => {
    try {
      const sql = await getSql();
      const rows = await sql<DeliveryZone>`
        select id, name, fee, eta_text
        from delivery_zones
        where is_active = true
        order by display_order
      `;
      return rows.length ? rows.map((r) => ({ ...r, fee: Number(r.fee) })) : FALLBACK_DELIVERY_ZONES;
    } catch {
      return FALLBACK_DELIVERY_ZONES;
    }
  },
);

export const listProducts = createServerFn({ method: "GET" })
  .validator(
    z.object({
      q: z.string().optional(),
      category: z.string().optional(),
      sort: z.enum(["new", "price_asc", "price_desc"]).optional(),
      featured: z.boolean().optional(),
      limit: z.number().int().min(1).max(60).optional(),
    }),
  )
  .handler(async ({ data }): Promise<ProductCard[]> => {
    const limit = data.limit ?? 24;
    const q = data.q?.trim();
    const cat = data.category?.trim();
    const sort = data.sort ?? "new";
    const order =
      sort === "price_asc"
        ? "p.price asc, p.created_at desc"
        : sort === "price_desc"
          ? "p.price desc, p.created_at desc"
          : "p.created_at desc";

    try {
      const sql = await getSql();
      const rows = await sql.query<CardRow>(
        `select ${CARD_SELECT}
         from products p
         left join categories c on c.id = p.category_id
         where p.is_active = true
           and ($1::text is null or p.search_text ilike '%' || $1 || '%' or p.name ilike '%' || $1 || '%')
           and ($2::text is null or c.slug = $2 or p.category_id = $2)
           and ($3::boolean is null or p.is_featured = $3)
         order by ${order}
         limit $4`,
        [q || null, cat || null, data.featured ?? null, limit],
      );
      if (rows.length) return rows.map(toCard);

      const fallbackRows = FALLBACK_PRODUCTS.filter(
        (p) => !q || `${p.name} ${p.sku}`.toLowerCase().includes(q.toLowerCase()),
      );
      const filtered = cat
        ? fallbackRows.filter((p) => p.category_slug === cat || p.category_id === cat)
        : fallbackRows;
      const featuredFiltered =
        data.featured == null ? filtered : filtered.filter((p) => p.is_featured === data.featured);
      const sorted = [...featuredFiltered].sort((a, b) =>
        sort === "price_asc" ? a.price - b.price : sort === "price_desc" ? b.price - a.price : 0,
      );
      return sorted.slice(0, limit);
    } catch {
      const fallbackRows = FALLBACK_PRODUCTS.filter(
        (p) => !q || `${p.name} ${p.sku}`.toLowerCase().includes(q.toLowerCase()),
      );
      const filtered = cat
        ? fallbackRows.filter((p) => p.category_slug === cat || p.category_id === cat)
        : fallbackRows;
      const featuredFiltered =
        data.featured == null ? filtered : filtered.filter((p) => p.is_featured === data.featured);
      const sorted = [...featuredFiltered].sort((a, b) =>
        sort === "price_asc" ? a.price - b.price : sort === "price_desc" ? b.price - a.price : 0,
      );
      return sorted.slice(0, limit);
    }
  });

export const getProductBySlug = createServerFn({ method: "GET" })
  .validator(z.object({ slug: z.string().min(1) }))
  .handler(async ({ data }): Promise<ProductDetail | null> => {
    try {
      const sql = await getSql();
      const rows = await sql.query<CardRow & { description: string; is_active: boolean }>(
        `select ${CARD_SELECT}, p.description, p.is_active
         from products p
         left join categories c on c.id = p.category_id
         where p.slug = $1
         limit 1`,
        [data.slug],
      );
      const row = rows[0];
      if (!row || !row.is_active) return null;
      const images = await sql<ProductImage>`
        select id, image_url, display_order, alt_text
        from product_images
        where product_id = ${row.id}
        order by display_order
      `;
      const variants = await sql<ProductVariant>`
        select id, product_id, size, color, sku, price, stock_quantity
        from product_variants
        where product_id = ${row.id}
        order by size
      `;
      return {
        ...toCard(row),
        description: row.description,
        low_stock_threshold: Number(row.low_stock_threshold),
        is_active: true,
        images,
        variants: variants.map((v) => ({
          ...v,
          price: v.price == null ? null : Number(v.price),
          stock_quantity: Number(v.stock_quantity),
        })),
      };
    } catch {
      return FALLBACK_DETAILS.find((p) => p.slug === data.slug) ?? null;
    }
  });

export const listRelated = createServerFn({ method: "GET" })
  .validator(z.object({ productId: z.string(), categoryId: z.string() }))
  .handler(async ({ data }): Promise<ProductCard[]> => {
    try {
      const sql = await getSql();
      const rows = await sql.query<CardRow>(
        `select ${CARD_SELECT}
         from products p
         left join categories c on c.id = p.category_id
         where p.is_active = true and p.category_id = $1 and p.id <> $2
         order by p.is_featured desc, p.created_at desc
         limit 6`,
        [data.categoryId, data.productId],
      );
      return rows.map(toCard);
    } catch {
      return FALLBACK_PRODUCTS.filter((p) => p.category_id === data.categoryId && p.id !== data.productId).slice(0, 6);
    }
  });

export const getProductsByIds = createServerFn({ method: "GET" })
  .validator(z.object({ ids: z.array(z.string()).max(40) }))
  .handler(async ({ data }): Promise<ProductCard[]> => {
    if (data.ids.length === 0) return [];
    try {
      const sql = await getSql();
      const rows = await sql.query<CardRow>(
        `select ${CARD_SELECT}
         from products p
         left join categories c on c.id = p.category_id
         where p.id = any($1::text[])`,
        [data.ids],
      );
      return rows.map(toCard);
    } catch {
      return FALLBACK_PRODUCTS.filter((p) => data.ids.includes(p.id));
    }
  });
