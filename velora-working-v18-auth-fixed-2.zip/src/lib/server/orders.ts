import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";

export type OrderListItem = {
  id: string;
  order_number: string;
  total: number;
  status: string;
  payment_status: string;
  payment_method: string;
  created_at: string;
};

export type OrderDetail = OrderListItem & {
  subtotal: number;
  delivery_fee: number;
  customer_name: string;
  customer_phone: string;
  delivery_address: string;
  notes: string | null;
  items: {
    id: string;
    product_name_snapshot: string;
    sku_snapshot: string;
    size_snapshot: string | null;
    quantity: number;
    unit_price: number;
    total_price: number;
    product_id: string | null;
  }[];
};

export const listMyOrders = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<OrderListItem[]> => {
    const sql = await getSql();
    const rows = await sql<OrderListItem>`
      select id, order_number, total, status, payment_status, payment_method,
             created_at::text as created_at
      from orders
      where user_id = ${context.userId}
      order by created_at desc
    `;
    return rows.map((r) => ({ ...r, total: Number(r.total) }));
  });

export const getMyOrder = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.string() }))
  .handler(async ({ context, data }): Promise<OrderDetail | null> => {
    const sql = await getSql();
    const rows = await sql.query<OrderDetail>(
      `select id, order_number, total, subtotal, delivery_fee, status, payment_status,
              payment_method, customer_name, customer_phone, delivery_address, notes,
              created_at::text as created_at
       from orders where id = $1 and user_id = $2`,
      [data.id, context.userId],
    );
    const order = rows[0];
    if (!order) return null;
    const items = await sql.query<OrderDetail["items"][number]>(
      `select id, product_name_snapshot, sku_snapshot, size_snapshot, quantity,
              unit_price, total_price, product_id
       from order_items where order_id = $1`,
      [order.id],
    );
    return {
      ...order,
      total: Number(order.total),
      subtotal: Number(order.subtotal),
      delivery_fee: Number(order.delivery_fee),
      items: items.map((i) => ({
        ...i,
        quantity: Number(i.quantity),
        unit_price: Number(i.unit_price),
        total_price: Number(i.total_price),
      })),
    };
  });
