import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { newId } from "@/lib/utils";
import { isMpesaCapable, normalizeKenyanPhone } from "@/lib/phone";
import { upsertProfile } from "./me";
import { mpesaConfigured, initiateStkPush } from "./mpesa";

const lineInput = z.object({
  productId: z.string(),
  variantId: z.string().nullable(),
  quantity: z.number().int().min(1).max(20),
});

export type QuotedLine = {
  productId: string;
  variantId: string | null;
  name: string;
  slug: string;
  sku: string;
  size: string | null;
  image: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
  stock: number;
};

export type Quote = {
  lines: QuotedLine[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  zoneName: string | null;
  currency: "KES";
};

type ProductRow = {
  id: string;
  name: string;
  slug: string;
  sku: string;
  price: number;
  main_image_url: string;
  stock_quantity: number;
  is_active: boolean;
};

type VariantRow = {
  id: string;
  product_id: string;
  size: string | null;
  sku: string;
  price: number | null;
  stock_quantity: number;
};

async function buildQuote(
  items: z.infer<typeof lineInput>[],
  zoneId?: string,
): Promise<Quote> {
  if (items.length === 0) {
    return { lines: [], subtotal: 0, deliveryFee: 0, total: 0, zoneName: null, currency: "KES" };
  }
  const sql = await getSql();
  const ids = [...new Set(items.map((i) => i.productId))];
  const products = await sql.query<ProductRow>(
    `select id, name, slug, sku, price, main_image_url, stock_quantity, is_active
     from products where id = any($1::text[])`,
    [ids],
  );
  const byId = new Map(products.map((p) => [p.id, p]));
  const variantIds = items.map((i) => i.variantId).filter((v): v is string => Boolean(v));
  const variants = variantIds.length
    ? await sql.query<VariantRow>(
        `select id, product_id, size, sku, price, stock_quantity from product_variants where id = any($1::text[])`,
        [variantIds],
      )
    : [];
  const varById = new Map(variants.map((v) => [v.id, v]));

  const lines: QuotedLine[] = [];
  for (const item of items) {
    const product = byId.get(item.productId);
    if (!product || !product.is_active) throw new Error("A product in your cart is no longer available.");
    const variant = item.variantId ? varById.get(item.variantId) : undefined;
    if (item.variantId && (!variant || variant.product_id !== product.id)) {
      throw new Error("A selected size is no longer available.");
    }
    const stock = variant ? Number(variant.stock_quantity) : Number(product.stock_quantity);
    if (item.quantity > stock) {
      throw new Error(`${product.name} only has ${stock} left.`);
    }
    const unitPrice = variant?.price != null ? Number(variant.price) : Number(product.price);
    lines.push({
      productId: product.id,
      variantId: variant?.id ?? null,
      name: product.name,
      slug: product.slug,
      sku: variant?.sku ?? product.sku,
      size: variant?.size ?? null,
      image: product.main_image_url,
      quantity: item.quantity,
      unitPrice,
      lineTotal: unitPrice * item.quantity,
      stock,
    });
  }
  const subtotal = lines.reduce((n, l) => n + l.lineTotal, 0);
  let deliveryFee = 0;
  let zoneName: string | null = null;
  if (zoneId) {
    const zones = await sql.query<{ name: string; fee: number }>(
      `select name, fee from delivery_zones where id = $1 and is_active = true`,
      [zoneId],
    );
    if (!zones[0]) throw new Error("Choose a valid delivery area.");
    deliveryFee = Number(zones[0].fee);
    zoneName = zones[0].name;
  }
  return { lines, subtotal, deliveryFee, total: subtotal + deliveryFee, zoneName, currency: "KES" };
}

export const quoteCart = createServerFn({ method: "POST" })
  .validator(
    z.object({
      items: z.array(lineInput).max(40),
      zoneId: z.string().optional(),
    }),
  )
  .handler(async ({ data }): Promise<Quote> => buildQuote(data.items, data.zoneId));

const checkoutInput = z.object({
  items: z.array(lineInput).min(1).max(40),
  customerName: z.string().min(2).max(80),
  customerPhone: z.string().min(9).max(20),
  mpesaPhone: z.string().min(9).max(20).optional(),
  address: z.string().min(4).max(200),
  city: z.string().min(2).max(80),
  zoneId: z.string(),
  notes: z.string().max(400).optional(),
  method: z.enum(["mpesa", "cod"]),
});

export type PlaceOrderResult = {
  orderId: string;
  orderNumber: string;
  total: number;
  method: "mpesa" | "cod";
  paymentStatus: string;
  orderStatus: string;
  mpesaConfigured: boolean;
  stk: { checkoutRequestId: string; customerMessage: string } | null;
  message: string;
};


export const placeOrder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(checkoutInput)
  .handler(async ({ context, data }): Promise<PlaceOrderResult> => {
    await upsertProfile(context.userId);
    const phone = normalizeKenyanPhone(data.customerPhone);
    if (!phone) throw new Error("Enter a valid Kenyan phone number.");
    let mpesaPhone: string | null = null;
    if (data.method === "mpesa") {
      const raw = data.mpesaPhone || data.customerPhone;
      mpesaPhone = normalizeKenyanPhone(raw);
      if (!mpesaPhone) throw new Error("Enter a valid M-Pesa number.");
      if (!isMpesaCapable(mpesaPhone)) {
        throw new Error("M-Pesa STK Push needs a Safaricom line (07…).");
      }
    }
    const quote = await buildQuote(data.items, data.zoneId);
    if (quote.total <= 0) throw new Error("Your cart is empty.");
    const sql = await getSql();
    const seq = await sql<{ n: number }>`select nextval('order_seq')::int as n`;
    const n = seq[0]?.n ?? Math.floor(Math.random() * 9000);
    const orderNumber = `VEL-${String(n).padStart(5, "0")}`;
    const orderId = newId("ord");
    const deliveryAddress = `${data.address.trim()}, ${data.city.trim()}${quote.zoneName ? ` · ${quote.zoneName}` : ""}`;

    if (data.method === "cod") {
      for (const line of quote.lines) {
        if (line.variantId) {
          const updated = await sql.query<{ id: string }>(
            `update product_variants set stock_quantity = stock_quantity - $1
             where id = $2 and stock_quantity >= $1 returning id`,
            [line.quantity, line.variantId],
          );
          if (!updated[0]) throw new Error(`${line.name} just went out of stock.`);
        } else {
          const updated = await sql.query<{ id: string }>(
            `update products set stock_quantity = stock_quantity - $1
             where id = $2 and stock_quantity >= $1 returning id`,
            [line.quantity, line.productId],
          );
          if (!updated[0]) throw new Error(`${line.name} just went out of stock.`);
        }
      }
    }

    await sql`
      insert into orders (
        id, user_id, order_number, subtotal, delivery_fee, total, currency,
        status, payment_status, payment_method, customer_name, customer_phone,
        mpesa_phone, delivery_address, delivery_zone_id, notes
      ) values (
        ${orderId}, ${context.userId}, ${orderNumber}, ${quote.subtotal}, ${quote.deliveryFee},
        ${quote.total}, 'KES',
        ${data.method === "cod" ? "confirmed" : "pending"},
        ${data.method === "cod" ? "pending" : "initiated"},
        ${data.method}, ${data.customerName.trim()}, ${phone}, ${mpesaPhone},
        ${deliveryAddress}, ${data.zoneId}, ${data.notes?.trim() || null}
      )
    `;
    for (const line of quote.lines) {
      await sql`
        insert into order_items (
          id, order_id, product_id, variant_id, product_name_snapshot, sku_snapshot,
          size_snapshot, quantity, unit_price, total_price
        ) values (
          ${newId("oi")}, ${orderId}, ${line.productId}, ${line.variantId}, ${line.name},
          ${line.sku}, ${line.size}, ${line.quantity}, ${line.unitPrice}, ${line.lineTotal}
        )
      `;
    }
    await sql`
      insert into notifications (id, user_id, title, body, link)
      values (
        ${newId("nt")}, ${context.userId}, ${"Order " + orderNumber},
        ${data.method === "cod"
          ? `We received your order. Pay ${quote.total} KSh on delivery.`
          : `Order placed. Complete M-Pesa payment of ${quote.total} KSh.`},
        ${"/account/orders/" + orderId}
      )
    `;

    if (data.method === "cod") {
      return {
        orderId,
        orderNumber,
        total: quote.total,
        method: "cod",
        paymentStatus: "pending",
        orderStatus: "confirmed",
        mpesaConfigured: mpesaConfigured(),
        stk: null,
        message: "Order confirmed. Pay the rider on delivery.",
      };
    }

    const paymentId = newId("pay");
    await sql`
      insert into payments (id, order_id, user_id, amount, currency, provider, phone_number, status)
      values (${paymentId}, ${orderId}, ${context.userId}, ${quote.total}, 'KES', 'mpesa', ${mpesaPhone}, 'initiated')
    `;

    if (!mpesaConfigured()) {
      return {
        orderId,
        orderNumber,
        total: quote.total,
        method: "mpesa",
        paymentStatus: "initiated",
        orderStatus: "pending",
        mpesaConfigured: false,
        stk: null,
        message:
          "Order saved. M-Pesa Daraja is not connected on this shop yet — the PIN prompt cannot be sent. Use Pay on delivery, or add Daraja credentials on the server.",
      };
    }

    const stk = await initiateStkPush({
      phone: mpesaPhone!,
      amount: quote.total,
      accountRef: orderNumber,
      description: `Velora ${orderNumber}`,
    });
    await sql`
      update payments
      set checkout_request_id = ${stk.checkoutRequestId},
          merchant_request_id = ${stk.merchantRequestId},
          updated_at = now()
      where id = ${paymentId}
    `;
    return {
      orderId,
      orderNumber,
      total: quote.total,
      method: "mpesa",
      paymentStatus: "initiated",
      orderStatus: "pending",
      mpesaConfigured: true,
      stk: { checkoutRequestId: stk.checkoutRequestId, customerMessage: stk.customerMessage },
      message: stk.customerMessage,
    };
  });

export const getPaymentStatus = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator(z.object({ orderId: z.string() }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const orders = await sql.query<{
      id: string;
      payment_status: string;
      status: string;
      order_number: string;
      total: number;
    }>(
      `select id, payment_status, status, order_number, total from orders where id = $1 and user_id = $2`,
      [data.orderId, context.userId],
    );
    const order = orders[0];
    if (!order) throw new Error("Order not found");
    const pays = await sql.query<{ status: string; result_desc: string | null }>(
      `select status, result_desc from payments where order_id = $1 order by created_at desc limit 1`,
      [data.orderId],
    );
    return {
      orderId: order.id,
      orderNumber: order.order_number,
      total: Number(order.total),
      paymentStatus: order.payment_status,
      orderStatus: order.status,
      lastPayment: pays[0]?.status ?? null,
      lastMessage: pays[0]?.result_desc ?? null,
    };
  });
