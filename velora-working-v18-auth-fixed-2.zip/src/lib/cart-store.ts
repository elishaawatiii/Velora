import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartLine } from "./types";

type CartState = {
  items: CartLine[];
  add: (line: { productId: string; variantId: string | null; quantity?: number }) => void;
  setQty: (productId: string, variantId: string | null, quantity: number) => void;
  remove: (productId: string, variantId: string | null) => void;
  clear: () => void;
  count: () => number;
};

function sameLine(a: CartLine, productId: string, variantId: string | null) {
  return a.productId === productId && (a.variantId ?? null) === (variantId ?? null);
}

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      add: ({ productId, variantId, quantity = 1 }) => {
        const items = [...get().items];
        const i = items.findIndex((l) => sameLine(l, productId, variantId));
        if (i >= 0) items[i] = { ...items[i], quantity: items[i].quantity + quantity };
        else items.push({ productId, variantId, quantity });
        set({ items });
      },
      setQty: (productId, variantId, quantity) => {
        if (quantity <= 0) {
          set({ items: get().items.filter((l) => !sameLine(l, productId, variantId)) });
          return;
        }
        set({
          items: get().items.map((l) =>
            sameLine(l, productId, variantId) ? { ...l, quantity } : l,
          ),
        });
      },
      remove: (productId, variantId) =>
        set({ items: get().items.filter((l) => !sameLine(l, productId, variantId)) }),
      clear: () => set({ items: [] }),
      count: () => get().items.reduce((n, l) => n + l.quantity, 0),
    }),
    { name: "velora-cart" },
  ),
);

type FollowState = { following: boolean; toggle: () => void };
export const useFollowStore = create<FollowState>()(
  persist(
    (set, get) => ({
      following: false,
      toggle: () => set({ following: !get().following }),
    }),
    { name: "velora-follow" },
  ),
);
