const DEFAULT_WA = "254745040360";

export function whatsappHref(phone: string | null | undefined, text: string): string {
  const digits = (phone || DEFAULT_WA).replace(/\D/g, "") || DEFAULT_WA;
  return `https://wa.me/${digits}?text=${encodeURIComponent(text)}`;
}

export function productInquiryText(opts: {
  name: string;
  sku: string;
  slug: string;
  origin?: string;
}): string {
  const url = opts.origin ? `${opts.origin}/product/${opts.slug}` : `/product/${opts.slug}`;
  return `Hi Velora, I have a question about ${opts.name} (SKU ${opts.sku}). ${url}`;
}

export function orderHelpText(orderNumber: string): string {
  return `Hi Velora, I need help with order ${orderNumber}.`;
}


export function cartOrderText(opts: {
  lines: Array<{ name: string; sku: string; quantity: number; unitPrice: number; variant?: string | null }>;
  total: number;
}): string {
  const lines = opts.lines.map((line, index) =>
    `${index + 1}. ${line.name}${line.variant ? ` (${line.variant})` : ""} — ${line.quantity} × KSh ${line.unitPrice.toLocaleString("en-KE")}\n   SKU: ${line.sku}`
  ).join("\n");
  return `Hi Velora, I would like to order these items via WhatsApp:\n\n${lines}\n\nEstimated subtotal: KSh ${opts.total.toLocaleString("en-KE")}\n\nPlease confirm availability, delivery cost and the final order total.\n\nI am ready to provide my delivery details.`;
}
