export type Category = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  image_url: string | null;
  is_active: boolean;
  display_order: number;
};

export type ProductCard = {
  id: string;
  name: string;
  slug: string;
  price: number;
  compare_at_price: number | null;
  main_image_url: string;
  sku: string;
  category_id: string;
  category_name: string | null;
  category_slug: string | null;
  stock_quantity: number;
  is_featured: boolean;
  low_stock: boolean;
};

export type ProductVariant = {
  id: string;
  product_id: string;
  size: string | null;
  color: string | null;
  sku: string;
  price: number | null;
  stock_quantity: number;
};

export type ProductImage = {
  id: string;
  image_url: string;
  display_order: number;
  alt_text: string | null;
};

export type ProductDetail = ProductCard & {
  description: string;
  low_stock_threshold: number;
  is_active: boolean;
  images: ProductImage[];
  variants: ProductVariant[];
};

export type DeliveryZone = {
  id: string;
  name: string;
  fee: number;
  eta_text: string;
};

export type CartLine = {
  productId: string;
  variantId: string | null;
  quantity: number;
};

export type OrderStatus =
  | "pending"
  | "confirmed"
  | "processing"
  | "shipped"
  | "delivered"
  | "cancelled";

export type PaymentStatus =
  | "pending"
  | "initiated"
  | "paid"
  | "failed"
  | "cancelled"
  | "refunded";

export type StoreProfile = {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  role: "customer" | "admin";
};

export type StoreSettings = {
  store_name: string;
  store_tagline: string;
  whatsapp_phone: string;
  support_email: string;
};
