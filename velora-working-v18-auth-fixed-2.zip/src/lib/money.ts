/** Integer Kenyan shillings — never floats. */

export function formatKes(amount: number): string {
  const n = Number.isFinite(amount) ? Math.round(amount) : 0;
  return `KSh ${n.toLocaleString("en-KE")}`;
}

export function parseKesInput(raw: string): number | null {
  const cleaned = raw.replace(/[^\d]/g, "");
  if (!cleaned) return null;
  const n = Number.parseInt(cleaned, 10);
  return Number.isFinite(n) && n >= 0 ? n : null;
}
