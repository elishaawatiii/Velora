/* eslint-disable */
// @ts-nocheck
import { Route as rootRouteImport } from './routes/__root'
import { Route as IndexRouteImport } from './routes/index'
import { Route as ShopRouteImport } from './routes/shop'
import { Route as ProductSlugRouteImport } from './routes/product.$slug'
import { Route as CartRouteImport } from './routes/cart'
import { Route as CheckoutRouteImport } from './routes/checkout'
import { Route as LoginRouteImport } from './routes/login'
import { Route as AccountRouteImport } from './routes/account'
import { Route as AccountOrdersRouteImport } from './routes/account.orders'
import { Route as AccountOrdersIdRouteImport } from './routes/account.orders.$id'
import { Route as SavedRouteImport } from './routes/saved'
import { Route as AdminRouteImport } from './routes/admin'
import { Route as AdminLoginRouteImport } from './routes/admin.login'
import { Route as AdminImportRouteImport } from './routes/admin.import'
import { Route as ApiAuthSplatRouteImport } from './routes/api/auth/$'
import { Route as ApiHealthRouteImport } from './routes/api/health'
import { Route as ApiMpesaCallbackRouteImport } from './routes/api/mpesa.callback'

const IndexRoute = IndexRouteImport.update({id:'/',path:'/',getParentRoute:()=>rootRouteImport} as any)
const ShopRoute = ShopRouteImport.update({id:'/shop',path:'/shop',getParentRoute:()=>rootRouteImport} as any)
const ProductSlugRoute = ProductSlugRouteImport.update({id:'/product/$slug',path:'/product/$slug',getParentRoute:()=>rootRouteImport} as any)
const CartRoute = CartRouteImport.update({id:'/cart',path:'/cart',getParentRoute:()=>rootRouteImport} as any)
const CheckoutRoute = CheckoutRouteImport.update({id:'/checkout',path:'/checkout',getParentRoute:()=>rootRouteImport} as any)
const LoginRoute = LoginRouteImport.update({id:'/login',path:'/login',getParentRoute:()=>rootRouteImport} as any)
const AccountRoute = AccountRouteImport.update({id:'/account',path:'/account',getParentRoute:()=>rootRouteImport} as any)
const AccountOrdersRoute = AccountOrdersRouteImport.update({id:'/account/orders',path:'/account/orders',getParentRoute:()=>rootRouteImport} as any)
const AccountOrdersIdRoute = AccountOrdersIdRouteImport.update({id:'/account/orders/$id',path:'/account/orders/$id',getParentRoute:()=>rootRouteImport} as any)
const SavedRoute = SavedRouteImport.update({id:'/saved',path:'/saved',getParentRoute:()=>rootRouteImport} as any)
const AdminRoute = AdminRouteImport.update({id:'/admin',path:'/admin',getParentRoute:()=>rootRouteImport} as any)
const AdminLoginRoute = AdminLoginRouteImport.update({id:'/admin/login',path:'/admin/login',getParentRoute:()=>rootRouteImport} as any)
const AdminImportRoute = AdminImportRouteImport.update({id:'/admin/import',path:'/admin/import',getParentRoute:()=>rootRouteImport} as any)
const ApiAuthSplatRoute = ApiAuthSplatRouteImport.update({id:'/api/auth/$',path:'/api/auth/$',getParentRoute:()=>rootRouteImport} as any)
const ApiHealthRoute = ApiHealthRouteImport.update({id:'/api/health',path:'/api/health',getParentRoute:()=>rootRouteImport} as any)
const ApiMpesaCallbackRoute = ApiMpesaCallbackRouteImport.update({id:'/api/mpesa/callback',path:'/api/mpesa/callback',getParentRoute:()=>rootRouteImport} as any)

export interface FileRoutesByFullPath {
 '/':typeof IndexRoute; '/shop':typeof ShopRoute; '/product/$slug':typeof ProductSlugRoute; '/cart':typeof CartRoute; '/checkout':typeof CheckoutRoute; '/login':typeof LoginRoute; '/account':typeof AccountRoute; '/account/orders':typeof AccountOrdersRoute; '/account/orders/$id':typeof AccountOrdersIdRoute; '/saved':typeof SavedRoute; '/admin':typeof AdminRoute; '/admin/login':typeof AdminLoginRoute; '/admin/import':typeof AdminImportRoute; '/api/auth/$':typeof ApiAuthSplatRoute; '/api/health':typeof ApiHealthRoute; '/api/mpesa/callback':typeof ApiMpesaCallbackRoute
}
export interface FileRoutesByTo extends FileRoutesByFullPath {}
export interface FileRoutesById { __root__:typeof rootRouteImport; '/':typeof IndexRoute; '/shop':typeof ShopRoute; '/product/$slug':typeof ProductSlugRoute; '/cart':typeof CartRoute; '/checkout':typeof CheckoutRoute; '/login':typeof LoginRoute; '/account':typeof AccountRoute; '/account/orders':typeof AccountOrdersRoute; '/account/orders/$id':typeof AccountOrdersIdRoute; '/saved':typeof SavedRoute; '/admin':typeof AdminRoute; '/admin/login':typeof AdminLoginRoute; '/admin/import':typeof AdminImportRoute; '/api/auth/$':typeof ApiAuthSplatRoute; '/api/health':typeof ApiHealthRoute; '/api/mpesa/callback':typeof ApiMpesaCallbackRoute }
export interface FileRouteTypes { fileRoutesByFullPath:FileRoutesByFullPath; fullPaths:keyof FileRoutesByFullPath; fileRoutesByTo:FileRoutesByTo; to:keyof FileRoutesByFullPath; id:keyof FileRoutesById; fileRoutesById:FileRoutesById }
export interface RootRouteChildren { IndexRoute:typeof IndexRoute; ShopRoute:typeof ShopRoute; ProductSlugRoute:typeof ProductSlugRoute; CartRoute:typeof CartRoute; CheckoutRoute:typeof CheckoutRoute; LoginRoute:typeof LoginRoute; AccountRoute:typeof AccountRoute; AccountOrdersRoute:typeof AccountOrdersRoute; AccountOrdersIdRoute:typeof AccountOrdersIdRoute; SavedRoute:typeof SavedRoute; AdminRoute:typeof AdminRoute; AdminLoginRoute:typeof AdminLoginRoute; AdminImportRoute:typeof AdminImportRoute; ApiAuthSplatRoute:typeof ApiAuthSplatRoute; ApiHealthRoute:typeof ApiHealthRoute; ApiMpesaCallbackRoute:typeof ApiMpesaCallbackRoute }
const rootRouteChildren:RootRouteChildren={IndexRoute,ShopRoute,ProductSlugRoute,CartRoute,CheckoutRoute,LoginRoute,AccountRoute,AccountOrdersRoute,AccountOrdersIdRoute,SavedRoute,AdminRoute,AdminLoginRoute,AdminImportRoute,ApiAuthSplatRoute,ApiHealthRoute,ApiMpesaCallbackRoute}
export const routeTree=rootRouteImport._addFileChildren(rootRouteChildren)._addFileTypes<FileRouteTypes>()
import type { getRouter } from './router.tsx'
import type { createStart } from '@tanstack/react-start'
declare module '@tanstack/react-start' { interface Register { ssr:true; router:Awaited<ReturnType<typeof getRouter>> } }
