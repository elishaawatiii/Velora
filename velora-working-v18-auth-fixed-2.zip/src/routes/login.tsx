import { FormEvent, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Eye, EyeOff, Check, X } from "lucide-react";
import { authClient } from "@/lib/auth/client";
import { getMyProfile } from "@/lib/server/me";

export const Route = createFileRoute("/login")({ component: LoginPage });

type Strength = "weak" | "fair" | "good" | "strong";

function passwordStrength(password: string): { level: Strength; label: string } {
  if (!password) return { level: "weak", label: "Enter a password" };
  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
  if (/\d/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;
  if (score <= 1) return { level: "weak", label: "Weak password" };
  if (score === 2) return { level: "fair", label: "Fair password" };
  if (score === 3) return { level: "good", label: "Good password" };
  return { level: "strong", label: "Strong password" };
}

function PasswordField({
  label,
  value,
  onChange,
  autoComplete,
  id,
  name,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  autoComplete: "current-password" | "new-password" | "off";
  id: string;
  name?: string;
}) {
  const [show, setShow] = useState(false);
  return (
    <label htmlFor={id} className="password-field-label">
      {label}
      <span className="password-input-wrap">
        <input
          id={id}
          name={name ?? id}
          required
          type={show ? "text" : "password"}
          minLength={8}
          maxLength={128}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          autoComplete={autoComplete}
          spellCheck={false}
        />
        <button
          type="button"
          className="password-toggle"
          aria-label={show ? `Hide ${label.toLowerCase()}` : `Show ${label.toLowerCase()}`}
          aria-pressed={show}
          onClick={() => setShow((v) => !v)}
        >
          {show ? <EyeOff size={18} aria-hidden="true" /> : <Eye size={18} aria-hidden="true" />}
        </button>
      </span>
    </label>
  );
}

function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [name, setName] = useState("");
  const [register, setRegister] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const strength = useMemo(() => passwordStrength(password), [password]);
  const passwordsMatch = !register || (confirmPassword.length > 0 && password === confirmPassword);

  function switchMode(next: boolean) {
    setRegister(next);
    setError("");
    setPassword("");
    setConfirmPassword("");
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    const cleanEmail = email.trim().toLowerCase();
    if (register) {
      if (password.length < 8) return setError("Your password must be at least 8 characters.");
      if (password !== confirmPassword) return setError("Your passwords do not match.");
      if (!name.trim()) return setError("Please enter your name.");
    }
    setBusy(true);
    try {
      const r = register
        ? await authClient.signUp.email({ email: cleanEmail, password, name: name.trim() })
        : await authClient.signIn.email({ email: cleanEmail, password });
      if (r.error) throw new Error(r.error.message);
      // Force a fresh server-backed session read after the cookie is set.
      // This prevents the account UI and protected pages from disagreeing about auth.
      const session = await authClient.getSession({ query: { disableCookieCache: true } });
      if (!session.data?.user) throw new Error("Sign-in succeeded but the session could not be established. Please try again.");
      const nextParam = new URLSearchParams(window.location.search).get("next");
      let destination = nextParam || "/account";
      try {
        const profile = await getMyProfile();
        if (profile.role === "admin" && !nextParam) destination = "/admin";
      } catch {
        // The authentication session is valid; profile loading can recover on the destination page.
      }
      window.location.replace(destination);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Authentication failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth-page">
      <a className="brand auth-brand" href="/">Velora</a>
      <form className="auth-card" onSubmit={submit} autoComplete={register ? "off" : "on"} noValidate>
        <span className="kicker">VELORA ACCOUNT</span>
        <h1>{register ? "Create your account" : "Welcome back"}</h1>
        <p>{register ? "Save your items, checkout faster and track your orders." : "Sign in to checkout and view your orders."}</p>

        {register && (
          <label htmlFor="name">Full name<input id="name" name="name" required maxLength={80} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" /></label>
        )}
        <label htmlFor="email">Email<input id="email" name="email" required type="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" /></label>
        <PasswordField id="password" name="password" label="Password" value={password} onChange={setPassword} autoComplete={register ? "new-password" : "current-password"} />

        {register && password && (
          <div className={`password-strength strength-${strength.level}`} aria-live="polite">
            <div className="strength-track"><span /></div>
            <small>{strength.label}</small>
            <ul className="password-rules">
              <li className={password.length >= 8 ? "valid" : ""}>{password.length >= 8 ? <Check size={13} /> : <X size={13} />} At least 8 characters</li>
              <li className={/[A-Z]/.test(password) && /[a-z]/.test(password) ? "valid" : ""}>{/[A-Z]/.test(password) && /[a-z]/.test(password) ? <Check size={13} /> : <X size={13} />} Upper + lowercase letters</li>
              <li className={/\d/.test(password) ? "valid" : ""}>{/\d/.test(password) ? <Check size={13} /> : <X size={13} />} A number</li>
              <li className={/[^A-Za-z0-9]/.test(password) ? "valid" : ""}>{/[^A-Za-z0-9]/.test(password) ? <Check size={13} /> : <X size={13} />} A special character</li>
            </ul>
          </div>
        )}

        {register && (
          <PasswordField id="confirm-password" name="confirmPassword" label="Confirm password" value={confirmPassword} onChange={setConfirmPassword} autoComplete="off" />
        )}
        {register && confirmPassword && <div className={`match-note ${passwordsMatch ? "valid" : "invalid"}`}>{passwordsMatch ? "✓ Passwords match" : "Passwords do not match"}</div>}
        {error && <div className="error-box" role="alert">{error}</div>}
        <button className="button primary full" disabled={busy || (register && !passwordsMatch)}>{busy ? "Please wait…" : register ? "Create account" : "Sign in"}</button>
        <button type="button" className="text-button" onClick={() => switchMode(!register)}>{register ? "Already have an account? Sign in" : "New to Velora? Create an account"}</button>
        {!register && <a className="auth-admin-link" href="/admin/login">Admin sign in</a>}
      </form>
    </main>
  );
}
