import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Minus, Plus, Trash2, MessageCircle } from "lucide-react";
import { StoreShell } from "@/components/store-shell";
import { useCart } from "@/lib/cart-store";
import { getProductsByIds } from "@/lib/server/catalog";
import { formatKes } from "@/lib/money";
import { whatsappHref, cartOrderText } from "@/lib/whatsapp";
import type { ProductCard } from "@/lib/types";
export const Route = createFileRoute("/cart")({component:CartPage});
function CartPage(){const {items,setQty,remove,clear}=useCart();const [products,setProducts]=useState<ProductCard[]>([]);useEffect(()=>{getProductsByIds({data:{ids:items.map(i=>i.productId)}}).then(setProducts)},[items]);const lines=items.map(i=>({item:i,p:products.find(p=>p.id===i.productId)})).filter(x=>x.p);const total=lines.reduce((s,l)=>s+l.p!.price*l.item.quantity,0);
const whatsappMessage=cartOrderText({lines:lines.map(({item,p})=>({name:p!.name,sku:p!.sku,quantity:item.quantity,unitPrice:p!.price,variant:null})),total});
return <StoreShell><main className="page narrow"><div className="page-title"><span className="kicker">YOUR BAG</span><h1>Cart</h1></div>{!lines.length?<div className="empty-state"><h2>Your cart is empty</h2><p>Find something you love and bring it home.</p><a className="button dark" href="/shop">Start shopping</a></div>:<><div className="cart-list">{lines.map(({item,p})=><div className="cart-line" key={`${item.productId}-${item.variantId}`}><img src={p!.main_image_url} alt=""/><div className="cart-line-copy"><a href={`/product/${p!.slug}`}><strong>{p!.name}</strong></a><small>{p!.sku}</small><strong>{formatKes(p!.price)}</strong></div><div className="qty"><button onClick={()=>setQty(item.productId,item.variantId,Math.max(1,item.quantity-1))}><Minus size={14}/></button><strong>{item.quantity}</strong><button onClick={()=>setQty(item.productId,item.variantId,Math.min(p!.stock_quantity,item.quantity+1))}><Plus size={14}/></button></div><button className="icon-button danger" onClick={()=>remove(item.productId,item.variantId)}><Trash2 size={17}/></button></div>)}</div><div className="cart-summary"><div><span>Subtotal</span><strong>{formatKes(total)}</strong></div><p>Delivery is calculated at checkout.</p><a className="button primary full" href="/checkout">Continue to checkout</a>
<a className="button whatsapp-order full" href={whatsappHref("254745040360", whatsappMessage)} target="_blank" rel="noreferrer"><MessageCircle size={18}/> Order through WhatsApp</a>
<button className="text-button" onClick={clear}>Clear cart</button></div></>}</main></StoreShell>}
