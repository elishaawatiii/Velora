import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { StoreShell } from "@/components/store-shell";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getMyProfile } from "@/lib/server/me";
import { adminImportProducts } from "@/lib/server/admin-import";
import { adminListCategories } from "@/lib/server/admin";

export const Route = createFileRoute("/admin/import")({ component: ImportProductsPage });
type Row = Record<string, string>;
const required = ["category", "name", "slug", "price", "stock_quantity", "sku", "main_image_url"];
function parseCSV(text: string): Row[] {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter((x) => x.trim());
  if (!lines.length) return [];
  const cells = (line: string) => { const out: string[]=[]; let cur="", quoted=false; for(let i=0;i<line.length;i++){const ch=line[i]; if(ch==='"' && line[i+1]==='"'){cur+='"';i++;continue;} if(ch==='"'){quoted=!quoted;continue;} if(ch===','&&!quoted){out.push(cur.trim());cur="";continue;} cur+=ch;} out.push(cur.trim()); return out; };
  const headers = cells(lines[0]).map((h)=>h.toLowerCase().replace(/\s+/g,"_"));
  return lines.slice(1).map(line => { const vals=cells(line); return Object.fromEntries(headers.map((h,i)=>[h,vals[i]??""])); });
}
function bool(v: string, fallback: boolean) { if(v===""||v==null) return fallback; return ["true","1","yes","y"].includes(v.toLowerCase()); }

function ImportProductsPage() {
  const { user, isPending } = useCurrentUserState();
  const [allowed,setAllowed]=useState<boolean|null>(null); const [rows,setRows]=useState<Row[]>([]); const [message,setMessage]=useState(""); const [busy,setBusy]=useState(false); const [categories,setCategories]=useState<any[]>([]);
  useEffect(()=>{if(user)getMyProfile().then(p=>setAllowed(p.role==="admin"));},[user]);
  useEffect(()=>{if(allowed)adminListCategories().then(setCategories).catch(()=>{});},[allowed]);
  async function readFile(file: File){setMessage(""); const data=parseCSV(await file.text()); setRows(data); const missing=required.filter(k=>!(k in (data[0]||{}))); setMessage(data.length?`${data.length} rows loaded${missing.length?` — missing columns: ${missing.join(", ")}`:" and ready to import."}`:"No rows found.");}
  async function importRows(){setBusy(true);setMessage("Importing…");try{const products=rows.map(r=>({...r,price:Number(r.price),compare_at_price:r.compare_at_price?Number(r.compare_at_price):null,stock_quantity:Number(r.stock_quantity),is_active:bool(r.is_active,true),is_featured:bool(r.is_featured,false)}));const result=await adminImportProducts({data:{products}});setMessage(`Imported/updated ${result.imported} products. ${result.failed} failed.`+(result.errors[0]?` First error: row ${result.errors[0].row} — ${result.errors[0].message}`:""));if(!result.failed)setRows([]);}catch(e){setMessage(e instanceof Error?e.message:"Import failed");}finally{setBusy(false);}}
  function downloadTemplate(){const header="category,name,slug,description,price,compare_at_price,stock_quantity,sku,main_image_url,is_active,is_featured\n";const sample=`${categories[0]?.slug||"category-slug"},Example Product,example-product,Product description,3500,4500,20,VEL-001,https://example.com/product.jpg,true,false\n`;const blob=new Blob([header+sample],{type:"text/csv;charset=utf-8"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="velora-products-template.csv";a.click();URL.revokeObjectURL(a.href);}
  if(isPending)return <StoreShell><main className="page"><div className="loading-page">Loading…</div></main></StoreShell>;
  if(!user||allowed===false)return <StoreShell><main className="page narrow"><div className="empty-state"><h2>Admin access required</h2><a className="button dark" href="/admin/login?next=/admin/import">Sign in</a></div></main></StoreShell>;
  return <StoreShell><main className="page narrow"><div className="page-title"><span className="kicker">VELORA ADMIN</span><h1>Import products</h1><p>Download the template, fill it in Excel or Google Sheets, then export/save it as CSV and upload it here.</p></div><div className="admin-import-card"><div className="import-actions"><button className="button dark" onClick={downloadTemplate}>Download CSV template</button><label className="button light">Choose CSV<input hidden type="file" accept=".csv,text/csv" onChange={e=>e.target.files?.[0]&&readFile(e.target.files[0])}/></label></div><p className="muted">Columns: category, name, slug, description, price, compare_at_price, stock_quantity, sku, main_image_url, is_active, is_featured.</p>{message&&<div className="info-box">{message}</div>}{rows.length>0&&<><div className="import-preview"><strong>Preview</strong><span>{rows.length} products</span></div><div className="table-scroll"><table><thead><tr><th>Name</th><th>SKU</th><th>Price</th><th>Stock</th></tr></thead><tbody>{rows.slice(0,8).map((r,i)=><tr key={i}><td>{r.name}</td><td>{r.sku}</td><td>KSh {r.price}</td><td>{r.stock_quantity}</td></tr>)}</tbody></table></div><button className="button dark full" disabled={busy} onClick={importRows}>{busy?"Importing…":`Import ${rows.length} products`}</button></>}</div></main></StoreShell>;
}
