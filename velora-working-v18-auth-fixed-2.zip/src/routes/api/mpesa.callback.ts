import { createFileRoute } from "@tanstack/react-router";
import { processMpesaCallback } from "@/lib/server/mpesa";

export const Route = createFileRoute("/api/mpesa/callback")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const json = (await request.json()) as Parameters<typeof processMpesaCallback>[0];
          await processMpesaCallback(json);
        } catch (err) {
          console.error("[mpesa callback]", err);
        }
        return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
          headers: { "content-type": "application/json" },
        });
      },
    },
  },
});
