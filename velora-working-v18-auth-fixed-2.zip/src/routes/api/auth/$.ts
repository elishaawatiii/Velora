import { createFileRoute } from "@tanstack/react-router";

/**
 * Keep the Better Auth server module out of the main SSR startup path.
 * Vercel can build the whole route tree up front; importing auth here used to
 * initialize the PGlite fallback even when /api/auth was never requested.
 */
export const Route = createFileRoute("/api/auth/$")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        if (!process.env.DATABASE_URL && (process.env.VERCEL === "1" || process.env.VERCEL_ENV)) {
          return new Response(JSON.stringify({ error: "Authentication database is not configured in Vercel. Add DATABASE_URL from Neon to the Vercel Production environment." }), {
            status: 503,
            headers: { "content-type": "application/json; charset=utf-8" },
          });
        }
        const { auth } = await import("@/lib/auth/server");
        const response = await auth.handler(request);
        response.headers.set("cache-control", "private, no-store, max-age=0");
        return response;
      },
      POST: async ({ request }) => {
        if (!process.env.DATABASE_URL && (process.env.VERCEL === "1" || process.env.VERCEL_ENV)) {
          return new Response(JSON.stringify({ error: "Authentication database is not configured in Vercel. Add DATABASE_URL from Neon to the Vercel Production environment." }), {
            status: 503,
            headers: { "content-type": "application/json; charset=utf-8" },
          });
        }
        const { auth } = await import("@/lib/auth/server");
        const response = await auth.handler(request);
        response.headers.set("cache-control", "private, no-store, max-age=0");
        return response;
      },
    },
  },
});
