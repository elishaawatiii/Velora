import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/health")({
  server: {
    handlers: {
      GET: async () => {
        const databaseConfigured = Boolean(process.env.DATABASE_URL?.trim());
        if (!databaseConfigured) {
          return Response.json({
            ok: true,
            app: "velora",
            database: "missing",
            auth: "not-ready",
            admin: "not-ready",
            runtime: process.env.VERCEL ? "vercel" : "node",
          });
        }
        try {
          const { getSql } = await import("@/lib/db");
          const sql = await getSql();
          const rows = await sql<{ users: number; credential_accounts: number; admins: number }>`
            select
              (select count(*)::int from "user") as users,
              (select count(*)::int from "account" where "providerId" = 'credential' and password is not null) as credential_accounts,
              (select count(*)::int from profiles where role = 'admin') as admins
          `;
          const row = rows[0] ?? { users: 0, credential_accounts: 0, admins: 0 };
          return Response.json({
            ok: true,
            app: "velora",
            database: "configured",
            auth: Number(row.credential_accounts) > 0 ? "ready" : "missing-credentials",
            admin: Number(row.admins) > 0 ? "ready" : "missing-admin-profile",
            runtime: process.env.VERCEL ? "vercel" : "node",
          });
        } catch (error) {
          return Response.json({
            ok: false,
            app: "velora",
            database: "error",
            auth: "unknown",
            admin: "unknown",
            runtime: process.env.VERCEL ? "vercel" : "node",
            error: error instanceof Error ? error.message : "Database check failed",
          }, { status: 503 });
        }
      },
    },
  },
});
