import { useEffect, useMemo, useState } from "react";
import { createFileRoute, useSearch } from "@tanstack/react-router";
import { StoreShell, SearchBar, ProductGrid } from "@/components/store-shell";
import { listCategories, listProducts } from "@/lib/server/catalog";
import type { Category, ProductCard } from "@/lib/types";

export const Route = createFileRoute("/shop")({ component: ShopPage });

function ShopPage() {
  const search = useSearch({ from: "/shop" }) as { q?: string; category?: string; sort?: string; featured?: string };
  const [products, setProducts] = useState<ProductCard[]>([]); const [categories, setCategories] = useState<Category[]>([]); const [loading, setLoading] = useState(true);
  useEffect(() => { setLoading(true); Promise.all([listProducts({data:{q:search.q, category:search.category, sort: search.sort === "price_asc" || search.sort === "price_desc" ? search.sort : "new", featured: search.featured === "1" ? true : undefined, limit:60}}), listCategories()]).then(([p,c])=>{setProducts(p);setCategories(c)}).finally(()=>setLoading(false)); }, [search.q, search.category, search.sort, search.featured]);
  const title = useMemo(() => search.category ? categories.find(c=>c.slug===search.category)?.name || "Shop" : search.q ? `Results for “${search.q}”` : search.featured === "1" ? "Featured" : "Shop all", [search,categories]);
  return <StoreShell><main className="page"><div className="shop-head"><div><span className="kicker">VELORA STORE</span><h1>{title}</h1><p>{products.length} pieces available</p></div><SearchBar defaultValue={search.q}/></div><div className="filter-row"><div className="chips"><a className={!search.category?"chip active":"chip"} href="/shop">All</a>{categories.map(c=><a key={c.id} className={search.category===c.slug?"chip active":"chip"} href={`/shop?category=${c.slug}`}>{c.name}</a>)}</div><div className="sorts"><a href={`/shop?${new URLSearchParams({...search,sort:"price_asc"} as any).toString()}`}>Price low</a><a href={`/shop?${new URLSearchParams({...search,sort:"price_desc"} as any).toString()}`}>Price high</a></div></div>{loading?<div className="product-grid">{Array.from({length:6}).map((_,i)=><div className="skeleton-card" key={i}/>)}</div>:<ProductGrid products={products}/>}</main></StoreShell>
}
