import { FormEvent, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Eye, EyeOff, ShieldCheck } from "lucide-react";
import { authClient } from "@/lib/auth/client";

export const Route = createFileRoute("/admin/login")({ component: AdminLoginPage });

function AdminLoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const next = new URLSearchParams(typeof window !== "undefined" ? window.location.search : "").get("next") || "/admin";

  async function submit(e: FormEvent) {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      const result = await authClient.signIn.email({ email: email.trim().toLowerCase(), password });
      if (result.error) throw new Error(result.error.message);
      const session = await authClient.getSession({ query: { disableCookieCache: true } });
      if (!session.data?.user) throw new Error("Admin sign-in succeeded but the session could not be established. Please try again.");
      window.location.replace(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Admin authentication failed");
    } finally { setBusy(false); }
  }

  return <main className="auth-page">
    <a className="brand auth-brand" href="/">Velora</a>
    <form className="auth-card" onSubmit={submit} autoComplete="on" noValidate>
      <div className="admin-login-mark"><ShieldCheck size={24} aria-hidden="true" /></div>
      <span className="kicker">VELORA ADMIN</span>
      <h1>Admin sign in</h1>
      <p>Administrator access is restricted to approved admin accounts.</p>
      <label htmlFor="admin-email">Email<input id="admin-email" name="email" required type="email" inputMode="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="username" /></label>
      <label htmlFor="admin-password">Password
        <span className="password-input-wrap">
          <input id="admin-password" name="password" required type={showPassword ? "text" : "password"} minLength={8} maxLength={128} value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" />
          <button type="button" className="password-toggle" aria-label={showPassword ? "Hide password" : "Show password"} aria-pressed={showPassword} onClick={() => setShowPassword(v => !v)}>{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button>
        </span>
      </label>
      {error && <div className="error-box" role="alert">{error}</div>}
      <button className="button primary full" disabled={busy}>{busy ? "Signing in…" : "Sign in as admin"}</button>
      <a className="text-button" href="/">Back to store</a>
    </form>
  </main>;
}
