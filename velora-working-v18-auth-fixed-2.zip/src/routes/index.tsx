import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, ChevronRight } from "lucide-react";
import { StoreShell, SearchBar, ProductGrid } from "@/components/store-shell";
import { listCategories, listProducts } from "@/lib/server/catalog";
import type { Category, ProductCard } from "@/lib/types";

export const Route = createFileRoute("/")({ component: HomePage });

function HomePage() {
  const [products, setProducts] = useState<ProductCard[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [featured, setFeatured] = useState<ProductCard[]>([]);
  useEffect(() => { Promise.all([listProducts({data:{limit:8}}), listProducts({data:{limit:6,featured:true}}), listCategories()]).then(([p,f,c]) => {setProducts(p);setFeatured(f);setCategories(c)}).catch(() => undefined); }, []);
  return <StoreShell>
    <main className="page">
      <section className="home-top home-hero-combined"><div className="home-hero-copy"><span className="kicker">NAIROBI BOUTIQUE</span><h1>Everyday fashion,<br/><em>your way.</em></h1><p>Curated pieces, easy ordering and delivery across Kenya.</p><Link className="button dark" to="/shop">Shop now <ArrowUpRight size={17}/></Link><SearchBar /></div><div className="hero-image"><img src="/products/promo-hero.jpg" alt="Velora fashion collection"/></div></section>
      <section className="promo promo-compact"><div><span>LIMITED OFFER</span><h2>First purchase, enjoy a special offer.</h2><Link to="/shop">Shop now <ArrowUpRight size={16}/></Link></div><img src="/products/denim-jacket.jpg" alt="Velora new arrival"/></section>
      <section className="section"><div className="section-heading"><div><span className="kicker">EXPLORE</span><h2>Categories</h2></div><Link to="/shop">See all <ChevronRight size={16}/></Link></div><div className="category-row">{categories.map(c => <Link className="category-card" to="/shop" search={{category:c.slug}} key={c.id}><img src={c.image_url || "/products/promo-hero.jpg"} alt=""/><strong>{c.name}</strong></Link>)}</div></section>
      <section className="section"><div className="section-heading"><div><span className="kicker">TRENDING NOW</span><h2>Most wanted</h2></div><Link to="/shop" search={{featured:"1"}}>See all <ChevronRight size={16}/></Link></div><ProductGrid products={(featured.length ? featured : products).slice(0,6)}/></section><section className="section"><div className="section-heading"><div><span className="kicker">JUST IN</span><h2>New arrivals</h2></div><Link to="/shop" search={{sort:"new"}}>See all <ChevronRight size={16}/></Link></div><ProductGrid products={products.slice(0,6)}/></section>
      <section className="trust-strip"><div><strong>Secure checkout</strong><span>M-Pesa supported</span></div><div><strong>Kenya-wide delivery</strong><span>Choose your delivery zone</span></div><div><strong>Need help?</strong><span>Chat with us on WhatsApp</span></div></section>
    </main>
  </StoreShell>
}
