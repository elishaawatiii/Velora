# Velora

Velora is a mobile-first Kenyan fashion storefront built with React + TanStack Start, PostgreSQL/PGLite, Better Auth, M-Pesa Daraja and WhatsApp click-to-chat.

## Deploy to Vercel

1. Upload the **contents of this project root** (the folder containing `package.json` and `vercel.json`).
2. Vercel should detect **TanStack Start**.
3. Add the production environment variables from `.env.example`.
4. Deploy.

The root route is `/` and the storefront routes are already included.

For a real production store, configure `DATABASE_URL` to a persistent PostgreSQL database and set `BETTER_AUTH_SECRET` + `BETTER_AUTH_URL`. Configure the Daraja variables before enabling real M-Pesa payments.

See `DEPLOY_VERCEL.md` for the exact deployment notes.


## Database access
Velora uses Neon PostgreSQL when `DATABASE_URL` is configured. You can inspect and manage the database directly from the Neon console using its SQL Editor, or connect with the PostgreSQL connection string. Keep the connection string private.

## Product import
Admins can open `/admin/import` and upload an Excel or CSV catalogue. Download the built-in Excel template first. The importer validates rows, matches categories, and upserts products by SKU. Product images currently use `main_image_url`; object-storage image uploads can be added later without changing the catalogue format.

## Commerce upgrades in this build
- Trending/featured product section on the storefront.
- Native product sharing with clipboard fallback.
- Recently viewed product tracking for future recommendation features.
- Excel/CSV product import for admins.
- Existing WhatsApp product enquiry and wishlist flows retained.


## Admin access
Set `VELORA_ADMIN_EMAILS` in Vercel Environment Variables to one or more approved email addresses, comma-separated. Open `/admin/login`, create/sign in with that email, and the server grants the admin role automatically. Never put an admin password in source code.

## Deploy updates
This project does not need to be deleted for updates. Connect the repository to Vercel/GitHub and every push to the production branch creates a new deployment while keeping the same project, database, domain and environment variables. You can also redeploy an existing commit from Vercel.


## Admin bootstrap

The production bootstrap admin is `admin@velora.co.ke`. The shipped migration creates this account in a fresh/updated database. Change the password after first login. `VELORA_ADMIN_EMAILS` defaults to this email and can be overridden in Vercel.
